using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Sandbox_Game.WorldGen;
using EpPathFinding.cs;

namespace Sandbox_Game.Entities.Pathfinding;

public static class PathfindingManager
{
    static JumpPointParam _jpParam;

    static Dictionary<(GridPos, GridPos), List<GridPos>> _pathCache = [];

    public static void Initialize(StaticGrid search_grid)
    {
        _jpParam = new JumpPointParam(search_grid, EndNodeUnWalkableTreatment.ALLOW, DiagonalMovement.OnlyWhenNoObstacles);
    }

    public static Vector2? Pathfind(Vector2 from_position, Vector2 to_position)
    {
        var start_point = new GridPos((int)Math.Floor(from_position.X / WorldGenerator.TileSize), (int)Math.Floor(from_position.Y / WorldGenerator.TileSize));

        var end_point = new GridPos((int)Math.Floor(to_position.X / WorldGenerator.TileSize), (int)Math.Floor(to_position.Y / WorldGenerator.TileSize));

        List<GridPos> path = [];

        if (_pathCache.TryGetValue((start_point, end_point), out List<GridPos> cached_path))
        {
            path = cached_path;
        }
        else
        {
            _jpParam.Reset(start_point, end_point);

            path = JumpPointFinder.FindPath(_jpParam);

            _pathCache.Add((start_point, end_point), path);
        }
        
        if (path == null)
        {
            return null;
        }

        if (path.Count <= 1)
        {
            return null;
        }

        return new Vector2(path[1].x, path[1].y) * WorldGenerator.TileSize;
    }
}