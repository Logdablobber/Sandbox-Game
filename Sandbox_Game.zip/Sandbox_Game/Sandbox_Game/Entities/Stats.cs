public struct Stats
{
    public int MaxHP;
    public float Strength;
    public float AttackSpeed;
    public float Speed;
    public int MaxMana;
    public float DecimalManaRegenPerSecond;
}