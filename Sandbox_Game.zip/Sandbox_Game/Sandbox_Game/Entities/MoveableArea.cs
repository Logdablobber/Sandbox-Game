using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using MonoGame.Extended;

namespace Sandbox_Game.Entities.MovableArea;

public class AreaCollider
{
    public List<BoundingRectangle> colliders;

    public AreaCollider()
    {
        colliders = [];
    }

    public void AddCollider(BoundingRectangle col)
    {
        colliders.Add(col);
    }

    public bool Collides(BoundingRectangle other)
    {
        foreach (var col in colliders)
        {
            if (col.Intersects(other))
            {
                return true;
            }
        }

        return false;
    }

    public bool Contains(BoundingRectangle other)
    {
        foreach (var col in colliders)
        {
            if (col.Intersection(other) == other)
            {
                return true;
            }
        }

        return false;
    }

    public bool CanSee(Vector2 origin, BoundingRectangle other)
    {
        Vector2 direction = other.Center - origin;
        direction.Normalize();

        Ray2 ray = new(origin, direction);

        float other_distance = Vector2.Distance(other.Center, origin);

        foreach (var col in colliders)
        {
            if (ray.Intersects(col, out float distance, out float _))
            {
                if (distance < other_distance && distance > 0)
                {
                    return false;
                }
            }
        }

        return true;
    }

    public bool CanMoveTo(BoundingRectangle origin, BoundingRectangle other)
    {
        List<(Vector2, Vector2)> corners = [];

        (sbyte, sbyte)[] corner_offsets = [(-1, -1), (1, -1), (1, 1), (-1, 1)];

        foreach (var corner_offset in corner_offsets)
        {
            Vector2 origin_corner = origin.Center + new Vector2(corner_offset.Item1 * origin.HalfExtents.X, corner_offset.Item2 * origin.HalfExtents.Y);
            Vector2 other_corner = other.Center + new Vector2(corner_offset.Item1 * other.HalfExtents.X, corner_offset.Item2 * other.HalfExtents.Y);

            corners.Add((origin_corner, other_corner));
        }

        foreach (var corner_set in corners)
        {
            Vector2 direction = corner_set.Item2 - corner_set.Item1;

            if (!(direction.X == 0 && direction.Y == 0))
            {
                direction.Normalize();

                Ray2 ray = new(corner_set.Item1, direction);

                float distance_to_player = Vector2.Distance(corner_set.Item1, corner_set.Item2);
        
                foreach (var col in colliders)
                {
                    if (ray.Intersects(col, out float distance, out float _))
                    {
                        if (distance < distance_to_player && distance > 0)
                        {
                            return false;
                        }
                    }
                }
            }
        }   

        return true;     
    }

}