using System.Collections.Generic;
using Microsoft.Xna.Framework;
using MonoGame.Extended;

namespace Sandbox_Game.Entities.MovableArea;

public class AreaCollider
{
    public List<BoundingBox> colliders;

    public AreaCollider()
    {
        colliders = [];
    }

    public void AddCollider(BoundingBox col)
    {
        colliders.Add(col);
    }

    public bool Collides(BoundingBox other)
    {
        foreach (var col in colliders)
        {
            if (col.Intersects(other))
            {
                return true;
            }
        }

        return false;
    }

    public bool Contains(BoundingBox other)
    {
        foreach (var col in colliders)
        {
            if (col.Contains(other) == ContainmentType.Contains)
            {
                return true;
            }
        }

        return false;
    }
}