using System.IO;
using Newtonsoft.Json;
using Sandbox_Game.Enums.PathfindingTypes;

namespace Sandbox_Game.Entities.Enemies.Reader;

public static class EnemyReader
{
    public static EnemyData ReadEnemyJson(string path)
    {
        EnemyData data = JsonConvert.DeserializeObject<EnemyData>(File.ReadAllText(path));

        data.pathfindingType = (PathfindingType)data.pathfindingTypeInt;

        return data;
    }
}