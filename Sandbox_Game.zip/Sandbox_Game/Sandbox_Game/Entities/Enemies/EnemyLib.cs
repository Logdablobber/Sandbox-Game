using System.Collections.Generic;

namespace Sandbox_Game.Entities.Enemies;

public static class EnemyLib
{
    public readonly static Dictionary<byte, List<(string, EnemyData)>> Enemies = [];
}