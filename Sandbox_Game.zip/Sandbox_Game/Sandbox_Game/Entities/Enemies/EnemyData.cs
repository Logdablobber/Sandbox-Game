using MonoGame.Extended.Graphics;
using Sandbox_Game.Enums.PathfindingTypes;

namespace Sandbox_Game.Entities.Enemies;

public class EnemyData
{
    public string Name;
    public byte CR;
    public int MaxHp;
    public float Strength;
    public float Speed;
    public float AttackSpeed;
    public float ChargeTime;
    public float ChargeSpeed;
    public bool Charge;
    public int pathfindingTypeInt;
    public PathfindingType pathfindingType;
    public int Range;
    public float FollowTime;
    public float MaxMovedDistance;
    public string AnimationName;
    public SpriteSheet spriteSheet;
    public string first_animation;
}