using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using MonoGame.Extended;
using MonoGame.Extended.Graphics;
using Sandbox_Game.Dungeon;
using Sandbox_Game.Entities.MovableArea;
using Sandbox_Game.Entities.Pathfinding;
using Sandbox_Game.Entities.Player;
using Sandbox_Game.Enums;
using Sandbox_Game.Enums.PathfindingTypes;
using Sandbox_Game.MainScreen;
using Sandbox_Game.WorldGen;

namespace Sandbox_Game.Entities.Enemies;

public class Enemy : Entity, ICombatable
{
    public byte CR { get; set; }

    public int MaxHP { get; set; }
    public int HP { get; set;}
    public float Strength { get; set; }
    public float AttackSpeed { get; set; }
    public float Speed { get; set; }
    public float ChargeTime { get; set; }
    public float ChargeSpeed { get; set; }
    public bool Charge { get; set; }

    private float _chargeTimer = 0f;
    private bool _charging = false;
    private bool _dashing = false;
    private Vector2? _dashDirection;

    private Vector2 _spawnPosition;

    public PathfindingType pathfindingType;
    public int Range;
    public float FollowTime;
    const float MaxFollowDistance = 200f;

    public float TimeSinceSeenPlayer;
    private Vector2? _attackFromPosition;
    private Vector2? _attackDirection;
    private Vector2? _launchToPosition;
    private float? _launchSpeed;
    private bool _launching;
    private const float KnockbackThreshold = 5f;

    private bool _timeout = false;
    private float _timeoutTimer = 0f;
    public float TimeoutTime = 3f;

    public bool Dying = false;

    private AreaCollider _movementArea;

    private static PlayerController _player => DungeonScreen.Player;

    public Enemy(EnemyData data, Vector2 position, Vector2 scale, AreaCollider movement_area) 
    : base(new AnimatedSprite(data.spriteSheet, data.first_animation), position, scale, true, tags:["enemy", "combatable"])
    {
        CR = data.CR;
        MaxHP = data.MaxHp;
        HP = MaxHP;
        Strength = data.Strength;
        AttackSpeed = data.AttackSpeed;
        Speed = data.Speed;
        pathfindingType = data.pathfindingType;
        Range = data.Range;
        ChargeTime = data.ChargeTime;
        ChargeSpeed = data.ChargeSpeed;
        Charge = data.Charge;
        FollowTime = data.FollowTime;
        _movementArea = movement_area;
        _spawnPosition = position;
        TimeSinceSeenPlayer = FollowTime;
    }

    public override void Move(Vector2 deltaPosition)
    {
        Position.X += deltaPosition.X;

        if (_movementArea.Collides(Hitbox))
        {
            Position.X -= deltaPosition.X;
        }

        Position.Y += deltaPosition.Y;

        if (_movementArea.Collides(Hitbox))
        {
            Position.Y -= deltaPosition.Y;
        }
    }
    
    public void Move(Vector2 deltaPosition, out bool hit_wall)
    {
        hit_wall = false;
        Position.X += deltaPosition.X;

        if (_movementArea.Collides(Hitbox))
        {
            Position.X -= deltaPosition.X;
            hit_wall = true;
        }

        Position.Y += deltaPosition.Y;

        if (_movementArea.Collides(Hitbox))
        {
            Position.Y -= deltaPosition.Y;
            hit_wall = true;
        }
    }

    private void PathfindMove(float deltaTime)
    {
        bool following_player = FollowingPlayer(deltaTime, out bool can_see);

        Vector2 pathfind_to_position = _player.Position;

        if (!following_player)
        {
            pathfind_to_position = _spawnPosition;
            goto PathfindBack;
        }

        if (can_see)
        {
            // if the enemy can see the player but can't move directly to it
            // then it should still pathfind
            // this is not part of the previous if statement
            // because it uses raycast and so I don't want to call it every time
            // even if the enemy can't see the player
            if (!_movementArea.CanMoveTo(Hitbox, _player.Hitbox))
            {
                goto CantMoveTo;
            }

            Vector2 direction = (_player.Position - Position).NormalizedCopy();

            if (float.IsNaN(direction.X) || float.IsNaN(direction.Y))
            {
                return;
            }

            Move(direction * Speed * deltaTime);
            return;
        }

        CantMoveTo:
        PathfindBack:

        Vector2? move_to_position = null;

        if (Vector2.Distance(Position, pathfind_to_position) > 3)
        {
            move_to_position = PathfindingManager.Pathfind(Position, pathfind_to_position);
        }

        if (move_to_position != pathfind_to_position && move_to_position.HasValue)
        {
            Vector2 direction = (move_to_position.Value - Position).NormalizedCopy();
            Move(direction * Speed * deltaTime);
        }
    }

    private bool FollowingPlayer(float deltaTime, out bool can_see)
    {
        if (Vector2.Distance(Position, _player.Position) > MaxFollowDistance)
        {
            can_see = false;
            return false;
        }

        can_see = _movementArea.CanSee(Position, _player.Hitbox);
        if (!can_see)
        {
            TimeSinceSeenPlayer += deltaTime;
            return TimeSinceSeenPlayer <= FollowTime;
        }

        TimeSinceSeenPlayer = 0f;
        return true;
    }

    private void Knockback(float deltaTime)
    {
        if (Vector2.Distance(Position, _launchToPosition.Value) < KnockbackThreshold)
        {
            _launching = false;
            return;
        }

        if (_dashing)
        {
            _dashing = false;
            _dashDirection = null;
        }
        else if (_charging)
        {
            _charging = false;
            _chargeTimer = 0f;
        }

        if (sprite.CurrentAnimation == "OnCharge")
        {
            sprite.SetAnimation("Moving");
        }

        Vector2 movement_direction = (_launchToPosition.Value - Position).NormalizedCopy();
        Move(movement_direction * _launchSpeed.Value * deltaTime);
    }

    private void Dash(float deltaTime)
    {
        if (!_dashDirection.HasValue)
        {
            _dashDirection = (_launchToPosition.Value - Position).NormalizedCopy();
        }

        _charging = false;
        Move(_dashDirection.Value * ChargeSpeed * deltaTime, out bool hit_wall);

        if (hit_wall)
        {
            _dashing = false;
            _dashDirection = null;
            sprite.SetAnimation("Moving");
            _timeout = true;
            _timeoutTimer = 0f;
        }
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        if (Dying)
        {
            if (!sprite.Controller.IsAnimating)
            {
                Destroy();
            }  
            return;
        }

        if (_timeout)
        {
            if (_timeoutTimer >= TimeoutTime)
            {
                _timeout = false;
            }
            else
            {
                _timeoutTimer += deltaTime;
            }
            return;
        }

        if (!sprite.Controller.IsAnimating)
        {
            sprite.SetAnimation("Moving");
        }

        if (_launching)
        {
            Knockback(deltaTime);
        }
        else if (_dashing)
        {
            Dash(deltaTime);
        }
        else if (!_charging)
        {
            PathfindMove(deltaTime);
        }  

        if ((Vector2.Distance(_player.Position, Position) < Range || _charging) && !_launching)
        {
            if (!Charge || _chargeTimer >= ChargeTime)
            {
                sprite.SetAnimation("OnAttack");

                if (!Charge)
                {
                    Launch(_player.Position, 500f);
                    _attackFromPosition = Position;
                    _attackDirection = (_player.Position - Position).NormalizedCopy();
                }
                else
                {
                    _dashing = true;
                    _charging = false;
                    _chargeTimer = 0f;
                }
            }
            else if (Charge)
            {
                if (!_charging)
                {
                    _charging = true;
                    sprite.SetAnimation("OnCharge");
                    _launchToPosition = _player.Position;
                }
                _chargeTimer += deltaTime;
            }
        }

        if (Hitbox.Intersects(_player.Hitbox))
        {
            Attack(_player);

            if (_attackFromPosition.HasValue)
            {
                Launch(_player.Position - (_attackDirection.Value * Range * 2f), 500f);
            }
            else
            {
                var launch_direction = new Vector2(random.Next(), random.Next()).NormalizedCopy();

                Launch(_player.Position - (launch_direction * Range * 2f), 500f);
            }
            
        }   
    }

    public void Hurt(float damage, Vector2? knockback = null, float? knockback_speed = null)
    {
        if (Dying)
        {
            return;
        }

        HP -= (int)damage;

        if (HP <= 0)
        {
            sprite.SetAnimation("OnDeath");
            Dying = true;
            return;
        }

        _timeout = false;

        sprite.SetAnimation("OnHit");

        if (knockback.HasValue)
        {
            Launch(Position + knockback.Value, knockback_speed.Value);
        }
    }

    public void Attack(ICombatable target)
    {
        target.Hurt(Strength, null, null);
    }

    public void Launch(Vector2 to_position, float speed)
    {
        _launchToPosition = to_position;
        _launchSpeed = speed;
        _launching = true;
    }
}