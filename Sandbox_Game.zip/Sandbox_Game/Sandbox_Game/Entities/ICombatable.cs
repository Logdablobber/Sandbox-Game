using Microsoft.Xna.Framework;

namespace Sandbox_Game.Entities;

public interface ICombatable
{
    int MaxHP { get; set; }
    int HP { get; set; }
    float Strength { get; set; }
    float AttackSpeed { get; set; }
    float Speed { get; set; }

    abstract void Hurt(float damage, Vector2? knockback, float? knockback_speed);
}