using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended;
using MonoGame.Extended.Graphics;
using MonoGame.Extended.Input;
using Sandbox_Game.Entities.MovableArea;
using Sandbox_Game.Entities.Projectiles;
using Sandbox_Game.Enums;
using Sandbox_Game.Utilities.Constants;

namespace Sandbox_Game.Entities.Player;

public class PlayerController : Entity
{
    public float MovementSpeed = 100f;

    private AreaCollider _unmovable_area;

    public float ProjectileSpeed = 100f;

    public PlayerController(AnimatedSprite sprite, Vector2 position, Vector2 scale, AreaCollider unmoveable_area = null) 
        : base(sprite, position, scale)
    {
        _unmovable_area = unmoveable_area;

        StartedMoving += (_, _) => { UpdateAnimation(true); };
        StoppedMoving += (_, _) => { UpdateAnimation(false); };
    }

    protected virtual void UpdateAnimation(bool moving)
    {
        switch (direction)
        {
            case Direction.Left:
                if (moving)
                {
                    sprite.SetAnimation("walk-left");
                }
                else
                {
                    sprite.SetAnimation("standby-left");
                }
                break;

            case Direction.Right:
                if (moving)
                {
                    sprite.SetAnimation("walk-right");
                }
                else
                {
                    sprite.SetAnimation("standby-right");
                }
                break;

            case Direction.Up:
                if (moving)
                {
                    sprite.SetAnimation("walk-back");
                }
                else
                {
                    sprite.SetAnimation("standby-back");
                }
                break;

            case Direction.Down:
                if (moving)
                {
                    sprite.SetAnimation("walk-front");
                }
                else
                {
                    sprite.SetAnimation("standby-front");
                }
                break;

            default:
                break;
        }
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        KeyboardStateExtended keystate = KeyboardExtended.GetState();

        GetMovementInputs(deltaTime, keystate);

        if (keystate.WasKeyPressed(Keys.Space))
        {
            switch (direction)
            {
                case Direction.Up:
                    ShootMagicBlast(new Vector2(0, -1));
                    break;

                case Direction.Down:
                    ShootMagicBlast(new Vector2(0, 1));
                    break;

                case Direction.Left:
                    ShootMagicBlast(new Vector2(-1, 0));
                    break;

                case Direction.Right:
                    ShootMagicBlast(new Vector2(1, 0));
                    break;

                default:
                    break;
            }
        }
    }

    private void GetMovementInputs(float deltaTime, KeyboardStateExtended keystate)
    {
        byte keys_down = 0b0000;

        if (keystate.IsKeyDown(Keys.W))
        {
            if (keystate.IsKeyDown(Keys.A) || keystate.IsKeyDown(Keys.D))
            {
                Move(new Vector2(0, -deltaTime * MovementSpeed * Consts.Root2Over2));
            }
            else
            {
                Move(new Vector2(0, -deltaTime * MovementSpeed));
            }

            keys_down |= 0b0001;

            direction = Direction.Up;
        }
        if (keystate.IsKeyDown(Keys.S))
        {
            if (keystate.IsKeyDown(Keys.A) || keystate.IsKeyDown(Keys.D))
            {
                Move(new Vector2(0, deltaTime * MovementSpeed * Consts.Root2Over2));
            }
            else
            {
                Move(new Vector2(0, deltaTime * MovementSpeed));
            }

            keys_down |= 0b0010;
            
            direction = Direction.Down;
        }
        if (keystate.IsKeyDown(Keys.A))
        {
            if (keystate.IsKeyDown(Keys.W) || keystate.IsKeyDown(Keys.S))
            {
                Move(new Vector2(-deltaTime * MovementSpeed * Consts.Root2Over2, 0));
            }
            else
            {
                Move(new Vector2(-deltaTime * MovementSpeed, 0));
            }

            keys_down |= 0b0100;

            direction = Direction.Left;
        }
        if (keystate.IsKeyDown(Keys.D))
        {
            if (keystate.IsKeyDown(Keys.W) || keystate.IsKeyDown(Keys.S))
            {
                Move(new Vector2(deltaTime * MovementSpeed * Consts.Root2Over2, 0));
            }
            else
            {
                Move(new Vector2(deltaTime * MovementSpeed, 0));
            }

            keys_down |= 0b1000;

            direction = Direction.Right;
        }

        if (sprite.CurrentAnimation.StartsWith("standby") && keys_down != byte.MinValue)
        {
            UpdateAnimation(true);
        }
        else if (sprite.CurrentAnimation.StartsWith("walk") && keys_down == byte.MinValue)
        {
            UpdateAnimation(false);
        }

        if (direction != previousDirection)
        {
            UpdateAnimation(keys_down > 0);

            previousDirection = direction;
        }
    }

    public void Move(Vector2 deltaPosition)
    {
        Position += deltaPosition;
        if (_unmovable_area == null)
        {
            return;
        }
        
        if (_unmovable_area.Collides(Hitbox))
        {
            Position -= deltaPosition;
        }
    }

    public void ShootMagicBlast(Vector2 direction)
    {
        new Projectile(Game1.Animations["Magic Blast"], sprite.GetBoundingRectangle(new Transform2(Position, 0, Scale)).Center, Scale, direction, ProjectileSpeed);
    }
}