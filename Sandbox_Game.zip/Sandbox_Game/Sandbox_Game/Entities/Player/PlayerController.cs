using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.VisualBasic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended;
using MonoGame.Extended.Graphics;
using MonoGame.Extended.Input;
using Sandbox_Game.Dungeon;
using Sandbox_Game.Entities.MovableArea;
using Sandbox_Game.Entities.Particles;
using Sandbox_Game.Entities.Player.Spells;
using Sandbox_Game.Entities.Projectiles;
using Sandbox_Game.Enums;
using Sandbox_Game.UI.SliderBar;
using Sandbox_Game.Utilities.Constants;

namespace Sandbox_Game.Entities.Player;

public class PlayerController : Entity, ICombatable
{
    public int MaxHP { get; set; }
    public int HP { get; set; }
    public float Strength { get; set; }
    public float AttackSpeed { get; set; }
    public float Speed { get; set; }
    private float _shotTimer = 0f;
    private AreaCollider _unmovable_area;

    public int MaxMana { get; set; }
    public float Mana { get; set; }
    public float DecimalManaRegenPerSecond { get; set; }

    public string SelectedSpell = "Magic Blast";

    private Slider _healthBar;
    private Slider _manaBar;

    public PlayerController(AnimatedSprite sprite, Vector2 position, Vector2 scale, bool in_dungeon, Stats? stats = null, AreaCollider unmoveable_area = null) 
        : base(sprite, position, scale, in_dungeon, tags:["player", "combatable"])
    {
        _unmovable_area = unmoveable_area;

        if (stats.HasValue)
        {
            MaxHP = stats.Value.MaxHP;
            Strength = stats.Value.Strength;
            AttackSpeed = stats.Value.AttackSpeed;
            Speed = stats.Value.Speed;
            MaxMana = stats.Value.MaxMana;
            DecimalManaRegenPerSecond = stats.Value.DecimalManaRegenPerSecond;
        }
        else
        {
            MaxHP = 100;
            Speed = 100f;
            MaxMana = 100;
            DecimalManaRegenPerSecond = 0.1f;
        }

        HP = MaxHP;
        Mana = MaxMana;

        StartedMoving += (_, _) => { UpdateAnimation(true); };
        StoppedMoving += (_, _) => { UpdateAnimation(false); };

        // Initiate Healthbar

        Vector2 healthbar_position = new (-175, 140);

        AnimatedSprite hp_background_animation = new (Game1.Animations["HP Bar Background"].Item1, Game1.Animations["HP Bar Background"].Item2);
        AnimatedSprite hp_foreground_animation = new (Game1.Animations["HP Bar Foreground"].Item1, Game1.Animations["HP Bar Foreground"].Item2);

        _healthBar = new Slider(hp_background_animation, hp_foreground_animation, healthbar_position, new Vector2(4f), min_value:0, max_value:MaxHP);

        // Initiate Mana Bar

        Vector2 mana_bar_position = new (-250, 40);

        AnimatedSprite mana_background_animation = new (Game1.Animations["Mana Bar Background"].Item1, Game1.Animations["Mana Bar Background"].Item2);
        AnimatedSprite mana_foreground_animation = new (Game1.Animations["Mana Bar Foreground"].Item1, Game1.Animations["Mana Bar Foreground"].Item2);

        _manaBar = new Slider(mana_background_animation, mana_foreground_animation, mana_bar_position, new Vector2(4f), min_value:0, max_value:MaxMana, rotation:-MathHelper.PiOver2);
    }

    protected virtual void UpdateAnimation(bool moving)
    {
        switch (direction)
        {
            case Direction.Left:
                if (moving)
                {
                    sprite.SetAnimation("walk-left");
                }
                else
                {
                    sprite.SetAnimation("standby-left");
                }
                break;

            case Direction.Right:
                if (moving)
                {
                    sprite.SetAnimation("walk-right");
                }
                else
                {
                    sprite.SetAnimation("standby-right");
                }
                break;

            case Direction.Up:
                if (moving)
                {
                    sprite.SetAnimation("walk-back");
                }
                else
                {
                    sprite.SetAnimation("standby-back");
                }
                break;

            case Direction.Down:
                if (moving)
                {
                    sprite.SetAnimation("walk-front");
                }
                else
                {
                    sprite.SetAnimation("standby-front");
                }
                break;

            default:
                break;
        }
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        KeyboardStateExtended keystate = KeyboardExtended.GetState();
        MouseStateExtended mousestate = MouseExtended.GetState();

        GetMovementInputs(deltaTime, keystate);

        if (keystate.WasKeyPressed(Keys.D1))
        {
            SelectedSpell = "Magic Blast";
        }

        if (keystate.WasKeyPressed(Keys.D2))
        {
            SelectedSpell = "Lightning Bolt";
        }

        if (keystate.WasKeyPressed(Keys.D3))
        {
            SelectedSpell = "Fireball";
        }

        if (keystate.WasKeyPressed(Keys.Space))
        {
            UseSpell(Game1.camera.ScreenToWorld(mousestate.Position.ToVector2()) - Position);
        }

        if (keystate.WasKeyPressed(Keys.C))
        {
            Heal(10);
        }

        _shotTimer += deltaTime;

        RegenMana(deltaTime);
    }

    private void RegenMana(float deltaTime)
    {
        float regen_amount = MaxMana * DecimalManaRegenPerSecond * deltaTime;

        Mana = Math.Clamp(Mana + regen_amount, 0, MaxMana);

        _manaBar.SetValue(Mana);
    }

    private void GetMovementInputs(float deltaTime, KeyboardStateExtended keystate)
    {
        byte keys_down = 0b0000;

        if (keystate.IsKeyDown(Keys.W))
        {
            if (keystate.IsKeyDown(Keys.A) || keystate.IsKeyDown(Keys.D))
            {
                Move(new Vector2(0, -deltaTime * Speed * Consts.Root2Over2));
            }
            else
            {
                Move(new Vector2(0, -deltaTime * Speed));
            }

            keys_down |= 0b0001;

            direction = Direction.Up;
        }
        if (keystate.IsKeyDown(Keys.S))
        {
            if (keystate.IsKeyDown(Keys.A) || keystate.IsKeyDown(Keys.D))
            {
                Move(new Vector2(0, deltaTime * Speed * Consts.Root2Over2));
            }
            else
            {
                Move(new Vector2(0, deltaTime * Speed));
            }

            keys_down |= 0b0010;
            
            direction = Direction.Down;
        }
        if (keystate.IsKeyDown(Keys.A))
        {
            if (keystate.IsKeyDown(Keys.W) || keystate.IsKeyDown(Keys.S))
            {
                Move(new Vector2(-deltaTime * Speed * Consts.Root2Over2, 0));
            }
            else
            {
                Move(new Vector2(-deltaTime * Speed, 0));
            }

            keys_down |= 0b0100;

            direction = Direction.Left;
        }
        if (keystate.IsKeyDown(Keys.D))
        {
            if (keystate.IsKeyDown(Keys.W) || keystate.IsKeyDown(Keys.S))
            {
                Move(new Vector2(deltaTime * Speed * Consts.Root2Over2, 0));
            }
            else
            {
                Move(new Vector2(deltaTime * Speed, 0));
            }

            keys_down |= 0b1000;

            direction = Direction.Right;
        }

        if (sprite.CurrentAnimation.StartsWith("standby") && keys_down != byte.MinValue)
        {
            UpdateAnimation(true);
        }
        else if (sprite.CurrentAnimation.StartsWith("walk") && keys_down == byte.MinValue)
        {
            UpdateAnimation(false);
        }

        if (direction != previousDirection)
        {
            UpdateAnimation(keys_down > 0);

            previousDirection = direction;
        }
    }

    public override void Move(Vector2 deltaPosition)
    {
        Position += deltaPosition;
        if (_unmovable_area == null)
        {
            return;
        }
        
        if (_unmovable_area.Collides(Hitbox))
        {
            Position -= deltaPosition;
        }
    }

    public void UseSpell(Vector2 direction)
    {
        if (!SpellLib.Spells.ContainsKey(SelectedSpell))
        {
            return;
        }

        SpellData spell = SpellLib.Spells[SelectedSpell];

        if (Mana < spell.ManaCost)
        {
            Debug.WriteLine("Not enough Mana");
            return;
        }

        if (_shotTimer < spell.Delay)
        {
            return;
        }
        _shotTimer = 0;

        RectangleF bounding_rect = sprite.GetBoundingRectangle(new Transform2(Position, 0, Scale));

        Vector2 origin;

        const float distance_to_hand = -4f;

        switch (this.direction)
        {
            case Direction.Down: case Direction.Left:
                origin = bounding_rect.BottomLeft + new Vector2(0, distance_to_hand);
                break;

            case Direction.Right: case Direction.Up:
                origin = bounding_rect.BottomRight + new Vector2(0, distance_to_hand);
                break;

            default:
                origin = bounding_rect.Center;
                break;
        }

        EntityManager.SpawnParticle("Arcana Particle", origin, Scale * 0.5f, inDungeon, alpha:0.7f);

        foreach (var proj in spell.ProjectileEffects)
        {
            float direction_in_degrees = MathHelper.ToDegrees(direction.ToAngle()) - 90;
            float direction_with_offset = direction_in_degrees + (float)proj.DegreeOffset;
            float direction_with_offset_radians = MathHelper.ToRadians(direction_with_offset);

            Vector2 projectile_direction = new Vector2(MathF.Cos(direction_with_offset_radians), MathF.Sin(direction_with_offset_radians));

            EntityManager.SpawnProjectile(proj.ProjectileName, origin, Scale, projectile_direction, inDungeon);
        }

        Mana -= (float)spell.ManaCost;
    }

    public void Hurt(float damage, Vector2? knockback = null, float? knockback_speed = null)
    {
        HP -= (int)damage;

        _healthBar.SetValue(HP);

        Debug.WriteLine(HP);
    }

    public void Heal(float amount)
    {
        HP += (int)amount;

        _healthBar.SetValue(HP);
    }
}