using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Newtonsoft.Json;
using Sandbox_Game.Enums.EffectTypes;
namespace Sandbox_Game.Entities.Player.Spells;

public static class SpellReader
{
    public static SpellData ReadSpellFromJson(string path)
    {
        SpellData data = JsonConvert.DeserializeObject<SpellData>(File.ReadAllText(path));

        return data;
    }
}