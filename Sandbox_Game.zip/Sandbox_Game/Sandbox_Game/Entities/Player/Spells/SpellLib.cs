using System.Collections.Generic;

namespace Sandbox_Game.Entities.Player.Spells;

public static class SpellLib
{
    public static readonly Dictionary<string, SpellData> Spells = [];
}