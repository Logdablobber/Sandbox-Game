using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;

namespace Sandbox_Game.Entities.Player.Spells;

public class SpellData
{
    public string Name;
    public string IconPath;
    public Texture2D Icon;
    public double Delay;
    public double ManaCost;
    public List<ProjectileEffect> ProjectileEffects;
}

public interface iEffect
{
    double Delay { get; set; }
}

public class ProjectileEffect : iEffect
{
    public double Delay { get; set;}
    public string ProjectileName { get; set; }
    public double DegreeOffset { get; set; }
}

