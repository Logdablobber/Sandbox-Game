using Microsoft.Xna.Framework;
using MonoGame.Extended.Graphics;

namespace Sandbox_Game.Entities.Particles;

public class Particle : Entity
{
    public Particle(AnimatedSprite sprite, Vector2 position, Vector2 scale, bool in_dungeon, float alpha = 1f) 
    : base(sprite, position, scale, in_dungeon, alpha:alpha, tags:["particle"])
    {

    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);

        if (!sprite.Controller.IsAnimating)
        {
            Destroy();
        }
    }  
}