using System.Collections.Generic;
using Microsoft.Xna.Framework;
using MonoGame.Extended.Graphics;
using Sandbox_Game.Entities.Enemies;
using Sandbox_Game.Entities.MovableArea;
using Sandbox_Game.Entities.Particles;
using Sandbox_Game.Entities.Projectiles;

namespace Sandbox_Game.Entities;

public static class EntityManager
{
    private static readonly List<Entity> _dungeonEntities = new List<Entity>();
    private static readonly List<Entity> _worldEntities = new List<Entity>();

    private static AreaCollider _movableArea;

    public static void Initialize(AreaCollider movable_area)
    {
        _movableArea = movable_area;
    }

    public static void AddEntity(Entity entity, bool in_dungeon)
    {
        if (in_dungeon)
        {
            _dungeonEntities.Add(entity);
        }
        else
        {
            _worldEntities.Add(entity);
        }
    }

    public static void RemoveEntity(Entity entity)
    {
        if (_dungeonEntities.Contains(entity))
        {
            _dungeonEntities.Remove(entity);
        }
        else if (_worldEntities.Contains(entity))
        {
            _worldEntities.Remove(entity);
        }
    }

    public static void UpdateAll(GameTime gameTime, bool in_dungeon)
    {
        if (in_dungeon)
        {
            for (int i = _dungeonEntities.Count - 1; i >= 0; i--)
            {
                _dungeonEntities[i].Update(gameTime);
            }
            return;
        }

        for (int i = _worldEntities.Count - 1; i >= 0; i--)
        {
            _worldEntities[i].Update(gameTime);
        }
    }

    public static void DrawAll(GameTime gameTime, bool in_dungeon)
    {
        if (in_dungeon)
        {
            foreach (var entity in _dungeonEntities)
            {
                entity.Draw(gameTime);
            }
            return;
        }

        foreach (var entity in _worldEntities)
        {
            entity.Draw(gameTime);
        }
    }

    public static List<Entity> GetEntities(bool in_dungeon)
    {
        if (in_dungeon)
        {
            return _dungeonEntities;
        }

        return _worldEntities;
    }

    public static Enemy SpawnEnemy(string enemy_name, Vector2 position, Vector2 scale, AreaCollider movement_area)
    {
        //return new Enemy(EnemyLib.Enemies[enemy_name], position, scale, movement_area);
        return null;
    }

    public static Particle SpawnParticle(string particle_name, Vector2 position, Vector2 scale, bool in_dungeon = true, float alpha = 1f)
    {
        return new Particle(new AnimatedSprite(Game1.Animations[particle_name].Item1, Game1.Animations[particle_name].Item2), position, scale, in_dungeon, alpha:alpha);
    }

    public static Projectile SpawnProjectile(string projectile_name, Vector2 position, Vector2 scale, Vector2 direction, bool in_dungeon = true, bool from_player = true)
    {
        return new Projectile(ProjectileLib.Projectiles[projectile_name], position, scale, direction, in_dungeon, from_player, _movableArea);
    }
}