using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace Sandbox_Game.Entities.Projectiles;

public static class ProjectileManager
{
    private static List<Projectile> _projectiles = new List<Projectile>();

    public static void AddProjectile(Projectile obj)
    {
        _projectiles.Add(obj);
    }

    public static void RemoveProjectile(Projectile obj)
    {
        _projectiles.Remove(obj);
    }

    public static void Update(GameTime gameTime)
    {
        foreach (var projectile in _projectiles)
        {
            projectile.Update(gameTime);
        }
    }

    public static void Draw(GameTime gameTime)
    {
        foreach (var projectile in _projectiles)
        {
            projectile.Draw(gameTime);
        }
    }
}