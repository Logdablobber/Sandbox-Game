using MonoGame.Extended.Graphics;

namespace Sandbox_Game.Entities.Projectiles;

public struct ProjectileData
{
    public string Name;
    public float Speed;
    public float Range;
    public float Damage;
    public float Delay;
    public float Knockback;
    public int Pierce;
    public bool Bounce;
    public bool PierceWalls;
    public bool Explode;
    public float ExplosionRange;
    public float MinExplosionDamage;
    public float HitAnimationScale;

    public string AnimationName;
    public SpriteSheet spriteSheet;
    public string first_animation;
}