using System.IO;
using Newtonsoft.Json;

namespace Sandbox_Game.Entities.Projectiles.Reader;

public static class ProjectileReader
{
    public static ProjectileData ReadProjectileJson(string path)
    {
        ProjectileData data = JsonConvert.DeserializeObject<ProjectileData>(File.ReadAllText(path));

        return data;
    }
}