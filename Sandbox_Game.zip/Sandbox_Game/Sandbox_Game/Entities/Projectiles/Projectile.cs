using System;
using System.Runtime.CompilerServices;
using Microsoft.Xna.Framework;
using MonoGame.Extended;
using MonoGame.Extended.Graphics;
using MonoGame.Extended.Particles.Modifiers.Interpolators;
using Sandbox_Game.Animations;
using Sandbox_Game.Entities.Enemies;
using Sandbox_Game.Entities.MovableArea;
using Sandbox_Game.Entities.Player;
using Sandbox_Game.Utilities.Functions;

namespace Sandbox_Game.Entities.Projectiles;

public class Projectile : Entity
{

    public Vector2 Direction;
    public float Speed, Damage, Range, Delay, KnockbackEffect;
    public bool FromPlayer;

    public int Pierce;
    private int _piercedCount = 0;
    private Entity previously_hit_entity = null;
    public bool PierceWalls;
    private AreaCollider _movable_area;

    public bool Explode;
    public float ExplosionRange;
    public float MinExplosionDamage;

    public float HitAnimationScale;

    public bool Bounce;

    private float _distanceTraveled = 0f;

    bool Moving = true;

    const float _bounceMinRange = 3f;
    const float _bounceMaxRange = 100f;

    public Projectile(ProjectileData data, Vector2 position, Vector2 scale, Vector2 direction, bool in_dungeon, bool from_player = true, AreaCollider movable_area = null) 
    : base (new AnimatedSprite(data.spriteSheet, data.first_animation), position, scale, in_dungeon, tags:["projectile"])
    {
        Direction = direction.NormalizedCopy();
        Speed = data.Speed;
        Damage = data.Damage;
        FromPlayer = from_player;
        Range = data.Range;
        KnockbackEffect = data.Knockback;
        Pierce = data.Pierce;
        Bounce = data.Bounce;
        PierceWalls = data.PierceWalls;
        Explode = data.Explode;
        ExplosionRange = data.ExplosionRange;
        HitAnimationScale = data.HitAnimationScale;
        MinExplosionDamage = data.MinExplosionDamage;
        _movable_area = movable_area;

        Rotation = MathF.Atan(Direction.Y / Direction.X);
        if (Direction.X < 0)
        {
            Rotation += (float)Math.PI;
        }
    }

    public override void Move(Vector2 deltaPosition)
    {
        base.Move(deltaPosition);

        if (!PierceWalls && _movable_area != null)
        {
            if (_movable_area.Collides(Hitbox))
            {
                if (Explode)
                {
                    TriggerExplosion(!FromPlayer);
                }
                Moving = false;
                sprite.SetAnimation("hit");
            }
        }
    }

    public override void Update(GameTime gameTime)
    {
        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        if (Moving)
        {
            Vector2 movement = Direction * Speed * deltaTime;
            Move(movement);
            _distanceTraveled += (float)Math.Sqrt(movement.X * movement.X + movement.Y * movement.Y);
            CheckForCollision();

            if (_distanceTraveled >= Range)
            {
                if (Explode)
                {
                    TriggerExplosion(!FromPlayer);
                }
                Moving = false;
                sprite.SetAnimation("hit");
            }
        }

        if (!sprite.Controller.IsAnimating)
        {
            Destroy();
        }

        base.Update(gameTime);
    }

    private void CheckForCollision()
    {
        Entity col_entity = null;
        bool is_player = false;

        foreach (var entity in EntityManager.GetEntities(inDungeon))
        {
            if (FromPlayer && entity.Tags.Contains("enemy"))
            {
                if (((Enemy)entity).Dying)
                {
                    continue;
                }
                
                if (Hitbox.Intersects(entity.Hitbox))
                {
                    col_entity = entity;
                    break;
                }    
            }
            else if (!FromPlayer && entity.Tags.Contains("player"))
            {
                if (Hitbox.Intersects(entity.Hitbox))
                {
                    is_player = true;
                    col_entity = entity;
                    break;
                }
            }
        }

        if (col_entity == null || col_entity == previously_hit_entity)
        {
            return;
        }

        HitEntity(col_entity, is_player);
    }

    private void HitEntity(Entity entity, bool is_player = false)
    {
        if (Explode)
        {
            TriggerExplosion(is_player);
        }
        else
        {
            ((ICombatable)entity).Hurt(Damage, Direction * KnockbackEffect, Speed);
        }

        _piercedCount++;
        if (_piercedCount > Pierce)
        {
            sprite.SetAnimation("hit");
            Moving = false;
            return;
        }

        previously_hit_entity = entity;
        
        if (Bounce)
        {
            Vector2? new_direction = GetDirectionToNearestEntity();
            if (new_direction.HasValue)
            {
                Direction = new_direction.Value;
            }
        }
    }

    private float GetExplosionModifier(float distance)
    {
        return Functs.InverseLerp(0, ExplosionRange, distance);
    }

    private bool GetExplosion(Entity entity, out float damage, out float knockback, out Vector2 knockback_direction)
    {   
        float distance = Vector2.Distance(Position, entity.Hitbox.ClosestPointTo(Position));

        if (distance > ExplosionRange)
        {
            damage = 0;
            knockback = 0;
            knockback_direction = Vector2.Zero;
            return false;
        }

        float modifier = GetExplosionModifier(distance);

        damage = MathHelper.Lerp(MinExplosionDamage, Damage, modifier);
        knockback = KnockbackEffect * modifier;
        knockback_direction = distance > 0 ? Vector2.Normalize(entity.Position - Position) : Vector2.Zero;

        return true;
    }

    private void TriggerExplosion(bool is_player = false)
    {
        foreach (var entity in EntityManager.GetEntities(inDungeon))
        {
            if (!entity.Tags.Contains("combatable"))
            {
                continue;
            }

            if (!is_player && entity.Tags.Contains("player"))
            {
                continue;
            }

            if (is_player && entity.Tags.Contains("entity"))
            {
                continue;
            }

            if (GetExplosion(entity, out float damage, out float knockback, out Vector2 knockback_direction))
            {
                ((ICombatable)entity).Hurt(damage, knockback * knockback_direction, knockback);
            }
        }
    }

    private Vector2? GetDirectionToNearestEntity()
    {
        if (FromPlayer)
        {
            Vector2? nearest_enemy_position = null;
            float? nearest_enemy_distance = null;

            foreach (var entity in EntityManager.GetEntities(inDungeon))
            {
                if (!entity.Tags.Contains("enemy"))
                {
                    continue;
                }

                float distance = Vector2.Distance(Position, entity.Position);

                if (distance < _bounceMinRange || distance > _bounceMaxRange || entity == previously_hit_entity)
                {
                    continue;
                }

                if (!nearest_enemy_position.HasValue)
                {
                    nearest_enemy_position = entity.Position;
                    nearest_enemy_distance = distance;
                    continue;
                }

                if (nearest_enemy_distance > distance)
                {
                    nearest_enemy_position = entity.Position;
                    nearest_enemy_distance = distance;
                    continue;
                }
            }

            if (!nearest_enemy_distance.HasValue)
            {
                return null;
            }

            return (nearest_enemy_position.Value - Position).NormalizedCopy();
        }

        return null;
    }

    public override void Draw(GameTime gameTime)
    {
        sprite.Draw(Game1.Spritebatch, Position, Rotation, Scale * (sprite.CurrentAnimation == "hit" ? HitAnimationScale : 1));
    }
}