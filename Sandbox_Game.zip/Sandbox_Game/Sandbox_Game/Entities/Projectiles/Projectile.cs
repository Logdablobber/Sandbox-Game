using System;
using Microsoft.Xna.Framework;
using MonoGame.Extended.Graphics;
using MonoGame.Extended.Particles.Modifiers.Interpolators;

namespace Sandbox_Game.Entities.Projectiles;

public class Projectile : Entity
{

    public Vector2 Direction;
    public float Speed;

    public Projectile(AnimatedSprite sprite, Vector2 position, Vector2 scale, Vector2 direction, float speed) : base (sprite, position, scale)
    {
        Direction = Vector2.Normalize(direction);
        Speed = speed;

        Rotation = MathF.Atan(Direction.Y / Direction.X);

        ProjectileManager.AddProjectile(this);
    }

    public override void Update(GameTime gameTime)
    {
        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        Position += Direction * Speed * deltaTime;

        base.Update(gameTime);
    }
}