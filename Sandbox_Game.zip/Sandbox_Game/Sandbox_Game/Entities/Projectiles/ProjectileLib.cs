using System.Collections.Generic;

namespace Sandbox_Game.Entities.Projectiles;

public static class ProjectileLib
{
    public static readonly Dictionary<string, ProjectileData> Projectiles = [];
}