using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using MonoGame.Extended;
using MonoGame.Extended.Graphics;
using Sandbox_Game.Enums;

namespace Sandbox_Game.Entities;

public class Entity : IUpdateable, IDrawable
{
    public AnimatedSprite sprite;
    public Vector2 Position, Scale;
    public float Rotation;

    protected static FastRandom random = new();

    public BoundingRectangle Hitbox 
    {
        get 
        {
            var bounding_rect = sprite.GetBoundingRectangle(new Transform2(Position, 0, Scale));

            return BoundingRectangle.CreateFrom(new Vector2(bounding_rect.Left, bounding_rect.Center.Y), bounding_rect.BottomRight);
        }
    }

    private int _drawOrder = 0;
    public int DrawOrder => _drawOrder;

    private bool _visible = true;
    public bool Visible => _visible;

    private bool _enabled = true;
    public bool Enabled => _enabled;

    private int _updateOrder = 0;
    public int UpdateOrder => _updateOrder;

    public Direction previousDirection;
    public Direction direction;

    public event EventHandler StartedMoving;
    public event EventHandler StoppedMoving;
    public event EventHandler<EventArgs> EnabledChanged;
    public event EventHandler<EventArgs> UpdateOrderChanged;
    public event EventHandler<EventArgs> DrawOrderChanged;
    public event EventHandler<EventArgs> VisibleChanged;

    public bool inDungeon;

    public List<string> Tags;

    public Entity(AnimatedSprite sprite, Vector2 position, Vector2 scale, bool in_dungeon, float rotation = 0, float alpha = 1f, List<string> tags = null)
    {
        this.sprite = sprite;
        this.Position = position;
        this.Scale = scale;
        Rotation = rotation;
        this.sprite.Alpha = alpha;
        inDungeon = in_dungeon;
        Tags = tags != null ? tags : [];

        EntityManager.AddEntity(this, in_dungeon);
    }

    public virtual void Move(Vector2 deltaPosition)
    {
        Position += deltaPosition;
    }

    public void StartMoving(EventArgs e)
    {
        StartedMoving?.Invoke(this, e);
    }

    public void StopMoving(EventArgs e)
    {
        StoppedMoving?.Invoke(this, e);
    }

    public virtual void Update(GameTime gameTime) 
    {
        sprite?.Update(gameTime);
    }

    public virtual void Draw(GameTime gameTime)
    {
        sprite.Draw(Game1.Spritebatch, Position, Rotation, Scale);
    }

    public virtual void Destroy()
    {
        EntityManager.RemoveEntity(this);
    }

    public virtual void Disable()
    {
        _enabled = false;
        _visible = false;
    }

    public virtual void Enable()
    {
        _enabled = true;
        _visible = true;
    }
}