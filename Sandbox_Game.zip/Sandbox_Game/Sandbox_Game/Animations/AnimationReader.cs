using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Graphics;
using Newtonsoft.Json;

namespace Sandbox_Game.Animations;

public static class AnimationReader
{
    public static SpriteSheet ReadAnimationJSON(Game game, string path, out string first_animation)
    {
        AnimationData data = JsonConvert.DeserializeObject<AnimationData>(File.ReadAllText(path));

        Texture2D spritesheet_texture = game.Content.Load<Texture2D>(data.SpritesheetPath);
        Texture2DAtlas spritesheet_atlas = Texture2DAtlas.Create($"atlas/{data.Name}", spritesheet_texture, data.RegionWidth, data.RegionHeight, margin:data.Margin, spacing:data.Spacing);
        SpriteSheet spriteSheet = new SpriteSheet($"spritesheet/{data.Name}", spritesheet_atlas);

        foreach (var animation in data.Animations)
        {
            spriteSheet.DefineAnimation(animation.Name, builder =>
            {
                builder.IsLooping(animation.IsLooping)
                        .IsPingPong(animation.IsPingPonging);

                foreach (var frame in animation.Frames)
                {
                    builder.AddFrame(frame.RegionIndex, TimeSpan.FromSeconds(frame.Duration));
                }
            });
        }

        first_animation = data.Animations[0].Name;

        return spriteSheet;
    }
}