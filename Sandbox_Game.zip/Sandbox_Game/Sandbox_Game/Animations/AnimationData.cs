using System.Collections.Generic;

namespace Sandbox_Game.Animations;

public struct AnimationData
{
    public string Name;
    public string SpritesheetPath;
    public int RegionHeight;
    public int RegionWidth;
    public int Margin;
    public int Spacing;

    public List<Animation> Animations;
}

public struct Animation
{
    public string Name;
    public bool IsLooping;
    public bool IsPingPonging;
    public List<Frame> Frames;
}

public struct Frame
{
    public int RegionIndex;
    public float Duration;
}