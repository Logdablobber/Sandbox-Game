using System;
using System.Collections.Generic;
using MonoGame.Extended.Tiled;

namespace WorldGen.Layers;

public static class WorldLayers
{
    // layer name, file name (without extension), Threshold to generate layer
    public static Layer[] Layers = 
    [
        new Layer("SandLayer", "sand-tileset", -20),
        new Layer("UpperSandLayer", "upper-sand-tileset", -10),
        new Layer("GrassLayer", "grass-tileset", 0),
        new Layer("UpperGrassLayer", "upper-grass-tileset", 40),
        new Layer("LowerMountainLayer", "lower-mountain-tileset", 80),
        new Layer("MountainLayer", "mountain-tileset", 87),
        new Layer("UpperMountainLayer", "upper-mountain-tileset", 95),
        new Layer("MountainPeakLayer", "mountain-peak-tileset", 105)
    ];

    public static TiledMapTileset DungeonTileset;
    public static uint DungeonTilesetGID;
}

public struct Layer
{
    public readonly string Name;
    public readonly string TilesetFileName;
    public readonly sbyte Threshold;
    public uint FirstGID;
    public TiledMapTileset tileset;

    public Layer(string name, string tileset_name, sbyte threshold)
    {
        Name = name;
        TilesetFileName = tileset_name;
        Threshold = threshold;
        FirstGID = 0;
        tileset = null;
    }
}
