using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using MonoGame.Extended.Tiled.Renderers;
using Sandbox_Game.MainScreen;
using Sandbox_Game.Utilities.Threads;

namespace Sandbox_Game.WorldGen;

public static class TilemapRenderingManager
{
    private static Dictionary<Point, TiledMapRenderer> _renderers => WorldScreen.tileMapRenderers;

    private static Point _loadedChunkCoordinate = Point.Zero;

    public static void Update(GameTime gameTime, Point chunk_coordinate)
    {
        UpdateRenderers(gameTime, chunk_coordinate);
    }

    public static void UpdateRenderers(GameTime gameTime, Point chunk_coordinate)
    {
        for (int y = 0; y < WorldScreen.RenderDiameter; y++)
        {
            for (int x = 0; x < WorldScreen.RenderDiameter; x++)
            {
                Point coord = chunk_coordinate + new Point(x - WorldScreen.RenderRadius, y - WorldScreen.RenderRadius);

                if (!_renderers.ContainsKey(coord))
                {
                    _renderers.Add(coord, new TiledMapRenderer(Game1.Graphics.GraphicsDevice, WorldGenerator.GetTilemapChunk(coord, WorldScreen.tilemaps)));
                }

                _renderers[coord].Update(gameTime);
            }
        }
        _loadedChunkCoordinate = chunk_coordinate;
    }

    public static void DrawRenderers(Matrix transformation_matrix)
    {
        for (int y = WorldScreen.RenderDiameter - 1; y >= 0; y--)
        {
            for (int x = WorldScreen.RenderDiameter - 1; x >= 0; x--)
            {
                Point coord = _loadedChunkCoordinate + new Point(x - WorldScreen.RenderRadius, y - WorldScreen.RenderRadius);

                if (_renderers.TryGetValue(coord, out var renderer))
                {
                    renderer.Draw(transformation_matrix);
                }
            }
        }
    }
}