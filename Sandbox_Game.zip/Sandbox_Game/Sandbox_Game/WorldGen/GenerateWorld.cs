using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using MonoGame.Extended;
using MonoGame.Extended.Tiled;
using PerlinNoise;
using Sandbox_Game.MainScreen;
using Sandbox_Game.Utilities.Threads;
using WorldGen.Layers;

namespace Sandbox_Game.WorldGen;

public static class WorldGenerator
{
    public const byte ChunkSize = 16;
    public const byte TileSize = 16;
    public const byte PercentChanceOfDungeon = 1;

    private const float _perlinPersistance = 0.2f, _perlinRoughness = 1.2f;

    private static FastNoiseLite _perlinNoise;


    public static void Initialize(int seed)
    {
        _perlinNoise = new FastNoiseLite(seed);
    }

    public static TiledMap GetTilemapChunk(Point chunk_coords, Dictionary<Point, TiledMap> tilemaps)
    {
        if (!tilemaps.ContainsKey(chunk_coords))
        {
            AddChunkToTilemap(chunk_coords, tilemaps);
        }

        return tilemaps[chunk_coords];
    }

    public static Chunk GetChunk(Point chunk_coords, Dictionary<Point, Chunk> chunks)
    {
        if (!chunks.ContainsKey(chunk_coords))
        {
            AddChunkToDictionary(chunk_coords, chunks); 
        }

        return chunks[chunk_coords];
    }

    public static void AddChunkToTilemap(Point chunk_coords, Dictionary<Point, TiledMap> tilemaps)
    {
        TiledMap new_tilemap = new TiledMap($"{chunk_coords.X},{chunk_coords.Y}", "", ChunkSize, ChunkSize, TileSize, TileSize, TiledMapTileDrawOrder.RightDown, TiledMapOrientation.Orthogonal);

        Chunk chunk = GetChunk(chunk_coords, WorldScreen.chunks);

        Vector2 chunk_offset = chunk_coords.ToVector2() * TileSize * ChunkSize;

        Vector2 half_tile_offset = new Vector2(TileSize * 0.5f);

        foreach (var layer in WorldLayers.Layers)
        {
            new_tilemap.AddTileset(layer.tileset, (int)layer.FirstGID);
            new_tilemap.AddLayer(new TiledMapTileLayer(layer.Name, "", ChunkSize, ChunkSize, TileSize, TileSize));

            var tilemap_layer = new_tilemap.GetLayer<TiledMapTileLayer>(layer.Name);

            tilemap_layer.Offset = chunk_offset - half_tile_offset; 

            for (byte y = 0; y < ChunkSize; y++)
            {
                for (byte x = 0; x < ChunkSize; x++)
                {             
                    tilemap_layer.SetTile(x, y, chunk.Layers[layer.Name][x, y] + layer.FirstGID);
                }
            }
        }

        if (chunk.Dungeon.HasValue)
        {
            new_tilemap.AddTileset(WorldLayers.DungeonTileset, (int)WorldLayers.DungeonTilesetGID);
            new_tilemap.AddLayer(new TiledMapTileLayer("DungeonLayer", "", ChunkSize, ChunkSize, TileSize, TileSize));

            var dungeon_layer = new_tilemap.GetLayer<TiledMapTileLayer>("DungeonLayer");

            dungeon_layer.Offset = chunk_offset;

            dungeon_layer.SetTile(chunk.Dungeon.Value.Item1, chunk.Dungeon.Value.Item2, WorldLayers.DungeonTilesetGID);
        }

        tilemaps.Add(chunk_coords, new_tilemap);
    }

    public static void AddChunkToDictionary(Point chunk_coords, Dictionary<Point, Chunk> chunks)
    {
        chunks.Add(chunk_coords, GenerateChunk(chunk_coords));
    }

    public static Chunk GenerateChunk(Point coords)
    {
        sbyte[,] base_chunk = GenerateBaseChunk(coords);

        var new_chunk = new Chunk();

        new_chunk.Coords = coords;
        new_chunk.Heights = base_chunk;

        new_chunk.Layers = new Dictionary<string, byte[,]>();
        foreach (var layer in WorldLayers.Layers)
        {
            var new_layer = GenerateSmoothedChunk(base_chunk, coords, layer.Threshold);

            new_chunk.Layers.Add(layer.Name, new_layer);
        }
        
        int chunk_seed = WorldScreen.seed + Math.Abs(coords.X + coords.Y);

        FastRandom random = new FastRandom(chunk_seed);

        if (random.Next(100) <= PercentChanceOfDungeon)
        {
            
            byte coord = (byte)random.Next(0, 15);
            if (new_chunk.Layers[WorldLayers.Layers[0].Name][coord, coord] != 0)
            {
                new_chunk.Dungeon = (coord, coord);
            }
            
        }

        return new_chunk;
    }

    private static byte[,] GenerateSmoothedChunk(sbyte[,] base_chunk, Point chunk_coords, sbyte threshold)
    {
        byte[,] smoothed_chunk = new byte[ChunkSize, ChunkSize];

        //generate chunk using binary method by checking 4 borders of offset tile
        //offset is shifted up and left by a half a tile
        for (sbyte y = 0; y < ChunkSize; y++)
        {
            for (sbyte x = 0; x < ChunkSize; x++)
            {
                byte tile_index = 0b0000;

                if (x != 0 && y != 0)
                {
                    if (base_chunk[x-1, y-1] > threshold)
                    {
                        tile_index |= 0b0001;
                    }
                }
                else if (x != 0)
                {
                    if (GetBaseTile(chunk_coords + new Point(0, -1), new Point(x - 1, ChunkSize - 1)) > threshold)
                    {
                        tile_index |= 0b0001;
                    }
                }
                else if (y != 0)
                {
                    if (GetBaseTile(chunk_coords + new Point(-1, 0), new Point(ChunkSize - 1, y - 1)) > threshold)
                    {
                        tile_index |= 0b0001;
                    }
                }
                else 
                {
                    if (GetBaseTile(chunk_coords + new Point(-1, -1), new Point(ChunkSize-1, ChunkSize-1)) > threshold)
                    {
                        tile_index |= 0b0001;
                    }
                }

                if (y != 0)
                {
                    if (base_chunk[x, y-1] > threshold)
                    {
                        tile_index |= 0b0010;
                    }
                }
                else
                {
                    if (GetBaseTile(chunk_coords + new Point(0, -1), new Point(x, ChunkSize - 1)) > threshold)
                    {
                        tile_index |= 0b0010;
                    }
                }

                if (base_chunk[x, y] > threshold)
                {
                    tile_index |= 0b0100;
                }

                if (x != 0)
                {
                    if (base_chunk[x-1, y] > threshold)
                    {
                        tile_index |= 0b1000;
                    }
                }
                else
                {
                    if (GetBaseTile(chunk_coords + new Point(-1, 0), new Point(ChunkSize - 1, y)) > threshold)
                    {
                        tile_index |= 0b1000;
                    }
                }

                smoothed_chunk[x, y] = tile_index;
            }
        }

        return smoothed_chunk;
    }

    private static sbyte[,] GenerateBaseChunk(Point coords)
    {
        sbyte[,] base_chunk = new sbyte[ChunkSize, ChunkSize];

        for (byte y = 0; y < ChunkSize; y++)
        {
            for (byte x = 0; x < ChunkSize; x++)
            {
                base_chunk[x, y] = GetBaseTile(coords, new Point(x, y));
            }
        }

        return base_chunk;
    }

    private static sbyte GetBaseTile(Point chunk_coords, Point tile_coords)
    {
        return (sbyte)(GetLayeredNoise((chunk_coords * new Point(16)) + tile_coords, 8) * 100);
    }

    private static float GetLayeredNoise(Point coords, int octaves)
    {
        float noise = 0;
        float frequency = 1;
        float factor = 1;

        for(int i = 0; i < octaves; i++){
            noise = noise + _perlinNoise.GetNoise(coords.X * frequency + i * 0.72354f, coords.Y * frequency * i * 0.72354f) * factor;
            factor *= _perlinPersistance;
            frequency *= _perlinRoughness;
        }

        return noise;
    }
}