using System.Collections;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace Sandbox_Game.WorldGen;

public struct Chunk
{
    public Point Coords;
    public sbyte[,] Heights;

    public Dictionary<string, byte[,]> Layers;

    public (byte, byte)? Dungeon;
}
