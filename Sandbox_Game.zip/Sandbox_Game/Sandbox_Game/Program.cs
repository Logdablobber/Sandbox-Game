﻿using var game = new Sandbox_Game.Game1();
game.Run();
