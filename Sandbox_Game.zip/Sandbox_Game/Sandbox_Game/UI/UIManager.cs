using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using MonoGame.Extended.Input;

namespace Sandbox_Game.UI;

public static class UIManager
{
	private static readonly List<UIElement> _UIElements = [];

	public static void Add(UIElement element)
	{
		_UIElements.Add(element);
	}

	public static void Remove(UIElement element)
	{
		_UIElements.Remove(element);
	}

	public static void Update(GameTime gameTime)
	{
		foreach (var element in _UIElements)
		{
			element.Update(gameTime);
		}

		CheckMouseEvents();
	}

	// Check if the mouse enters, exits, clicks, or releases any UIElements
	private static void CheckMouseEvents()
	{
		MouseStateExtended mousestate = MouseExtended.GetState();

		if (mousestate.DeltaPosition.X != 0 || mousestate.DeltaPosition.Y != 0) 
		{
			Vector2 mousepos = Game1.camera.ScreenToWorld(mousestate.Position.ToVector2());

			foreach (var element in _UIElements)
			{
				if (!element.MouseOn)
				{
					if (element.Hitbox.Contains(mousepos))
					{
						element.MouseEnter(EventArgs.Empty);
					}
				}
				else if (!element.Hitbox.Contains(mousepos))
				{
					element.MouseExit(EventArgs.Empty);
				}
			}
		}

		if (mousestate.WasButtonPressed(MouseButton.Left))
		{
			foreach(var element in _UIElements)
			{
				if (!element.MouseHeld && element.MouseOn)
				{
					element.Click(EventArgs.Empty);
				}
			}
		}
		else if (mousestate.WasButtonReleased(MouseButton.Left))
		{
			foreach(var element in _UIElements)
			{
				if (element.MouseHeld && element.MouseOn)
				{
					element.Release(EventArgs.Empty);
				}
			}
		}
	}

	public static void Draw(GameTime gameTime, bool zoomed_out)
	{
		foreach (var element in _UIElements)
		{
			if ((zoomed_out && element.DrawOnZoomedOut) || !zoomed_out)
			{
				element.Draw(gameTime);
			}
		}
	}

}