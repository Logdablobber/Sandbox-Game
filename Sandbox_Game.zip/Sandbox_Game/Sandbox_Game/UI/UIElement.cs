using System;
using Microsoft.Xna.Framework;
using MonoGame.Extended;
using MonoGame.Extended.Graphics;

namespace Sandbox_Game.UI;

public class UIElement : IUIElement, IUpdateable, IDrawable
{
	public AnimatedSprite Sprite { get; set; }
	public Vector2 Position { get; set; }
    public Vector2 WorldPosition 
    {
        get { return Position + Game1.camera.Center; }
    }
	public Vector2 Scale { get; set; }
	public float Rotation { get; set; }

	public BoundingRectangle Hitbox 
	{
		get
		{
			var bounding_rect = Sprite.GetBoundingRectangle(new Transform2(Position, 0, Scale));

            return BoundingRectangle.CreateFrom(new Vector2(bounding_rect.Left, bounding_rect.Center.Y), bounding_rect.BottomRight);
		}
	}

    public bool DrawOnZoomedOut { get; set; }

	private bool _enabled;
    public bool Enabled => _enabled;

	private int _updateOrder;
    public int UpdateOrder => _updateOrder;

	private int _drawOrder;
    public int DrawOrder => _drawOrder;

	private bool _visible;
    public bool Visible => _visible;

	public bool MouseOn { get; set; }
	public bool MouseHeld { get; set; }

    public event EventHandler<EventArgs> MouseEntered;
	public event EventHandler<EventArgs> MouseExited;
    public event EventHandler<EventArgs> Clicked;
    public event EventHandler<EventArgs> Released;
    public event EventHandler<EventArgs> EnabledChanged;
    public event EventHandler<EventArgs> UpdateOrderChanged;
    public event EventHandler<EventArgs> DrawOrderChanged;
    public event EventHandler<EventArgs> VisibleChanged;

	public UIElement(AnimatedSprite sprite, Vector2 position, Vector2 scale, float rotation = 0, bool draw_on_zoomed_out = false)
	{
		Sprite = sprite;
		Position = position;
		Scale = scale;
		Rotation = rotation;
        DrawOnZoomedOut = draw_on_zoomed_out;

        UIManager.Add(this);
	}

    public void MouseEnter(EventArgs e)
    {
		MouseOn = true;
        MouseEntered?.Invoke(this, e);
    }

    public void MouseExit(EventArgs e)
    {
		MouseOn = false;
		MouseHeld = false;
        MouseExited.Invoke(this, e);
    }

	public void Click(EventArgs e)
    {
		MouseHeld = true;
        Clicked?.Invoke(this, e);
    }

    public void Release(EventArgs e)
    {
		MouseHeld = false;
        Released?.Invoke(this, e);
    }

    public virtual void Update(GameTime gameTime)
    {
        Sprite.Update(gameTime);
    }

    public virtual void Draw(GameTime gameTime)
    {
        Sprite.Draw(Game1.Spritebatch, WorldPosition, Rotation, Scale);
    }

    public virtual void Destroy()
    {
        UIManager.Remove(this);
    }
}