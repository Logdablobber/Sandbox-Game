using System;
using Microsoft.Xna.Framework;
using MonoGame.Extended;
using MonoGame.Extended.Graphics;

namespace Sandbox_Game.UI;

public interface IUIElement
{
	AnimatedSprite Sprite { get; set; }
	Vector2 Position { get; set; }
	Vector2 Scale { get; set; }
	float Rotation { get; set; }

	BoundingRectangle Hitbox { get; }

	bool MouseOn { get; set; }
	bool MouseHeld { get; set; }

	bool DrawOnZoomedOut { get; set; }

	event EventHandler<EventArgs> MouseEntered;
	event EventHandler<EventArgs> MouseExited;
	event EventHandler<EventArgs> Clicked;
	event EventHandler<EventArgs> Released;

	abstract void MouseEnter(EventArgs e);
	abstract void MouseExit(EventArgs e);
	abstract void Click(EventArgs e);
	abstract void Release(EventArgs e);
}