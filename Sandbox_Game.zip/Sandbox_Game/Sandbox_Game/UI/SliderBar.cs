using Microsoft.Xna.Framework;
using MonoGame.Extended.Graphics;
using Sandbox_Game.Utilities.Functions;

namespace Sandbox_Game.UI.SliderBar;

public class Slider : UIElement
{
	private float _value;
	public float Value => _value;
	public float MinValue, MaxValue;

	public AnimatedSprite BarSprite { get; protected set; }
	private readonly int _defaultWidth;

	public Slider(AnimatedSprite sprite, AnimatedSprite bar_sprite, Vector2 position, Vector2 scale, float min_value = 0, float max_value = 100, float starting_value = 100, float rotation = 0)
	: base(sprite, position, scale, rotation, false)
	{
		_value = starting_value;
		MinValue = min_value;
		MaxValue = max_value;
		BarSprite = bar_sprite;

		_defaultWidth = bar_sprite.TextureRegion.Width;
	}

	public void ChangeValue(float amount)
	{
		SetValue(_value + amount);
	}

	public void SetValue(float value)
	{
		_value = MathHelper.Clamp(value, MinValue, MaxValue);
	}

	private void UpdateScale()
	{
		var subregion = BarSprite.TextureRegion.Bounds;
		subregion.Width = (int)(_defaultWidth * Functs.InverseLerp(MinValue, MaxValue, _value));

		BarSprite.TextureRegion = new Texture2DRegion(BarSprite.TextureRegion.Texture, subregion);
	}

	public override void Update(GameTime gameTime)
	{
		base.Update(gameTime);
		BarSprite.Update(gameTime);
	}

    public override void Draw(GameTime gameTime)
    {
        base.Draw(gameTime);
		UpdateScale();
		BarSprite.Draw(Game1.Spritebatch, WorldPosition, Rotation, Scale);
    }
}