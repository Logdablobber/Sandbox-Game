namespace Sandbox_Game.Enums.EffectTypes;

public enum EffectType
{
    None = 0,
    Projectile = 1,
}