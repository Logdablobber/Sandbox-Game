using System.Collections.Generic;

namespace Sandbox_Game.Enums;

public enum Direction
{
    Up,
    Down,
    Left,
    Right,
    None,
}

public static class OpposingDirections
{
    static Dictionary<Direction, Direction> Opposites = new Dictionary<Direction, Direction>
    {
        {Direction.Up, Direction.Down},
        {Direction.Left, Direction.Right},
        {Direction.Down, Direction.Up},
        {Direction.Right, Direction.Left},
        {Direction.None, Direction.None},
    };

    public static Direction Get(Direction direction)
    {
        return Opposites[direction];
    }
}