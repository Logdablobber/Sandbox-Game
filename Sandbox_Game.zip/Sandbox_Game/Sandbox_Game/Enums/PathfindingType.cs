namespace Sandbox_Game.Enums.PathfindingTypes;

public enum PathfindingType
{
    None = 0,
    FollowPlayer = 1,
    StayAtRange = 2,
    RunFromPlayer = 3
}