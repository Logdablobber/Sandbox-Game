using Microsoft.Xna.Framework;

namespace Sandbox_Game.Dungeon.Rendering;

public static class DungeonRenderer
{
    public static void Draw(DungeonScreen screen, Matrix TransformationMatrix)
    {
        if (!screen.DrawAllRooms)
        {
            for (byte y = 0; y < DungeonScreen.RenderDiameter; y++)
            {
                for (byte x = 0; x < DungeonScreen.RenderDiameter; x++)
                {
                    Point coord = screen.ChunkCoordinate - new Point(x - DungeonScreen.RenderRadius, y - DungeonScreen.RenderRadius);

                    if (coord.X <= 0 || coord.Y <= 0 || coord.X >= screen.dungeon.data.GetLength(0) || coord.Y >= screen.dungeon.data.GetLength(1))
                    {
                        continue;
                    }

                    screen.DungeonTilemaps[coord.X, coord.Y]?.Draw(TransformationMatrix);
                }
            }
        }
        else
        {
            for (int y = screen.DungeonTilemaps.GetLength(1) - 1; y >= 0; y--)
            {
                for (int x = screen.DungeonTilemaps.GetLength(0) - 1; x >= 0; x--)
                {
                    screen.DungeonTilemaps[x, y]?.Draw(TransformationMatrix);
                }
            }
        }
    }

    public static void Update(DungeonScreen screen, GameTime gameTime)
    {
        for (byte y = 0; y < DungeonScreen.RenderDiameter; y++)
        {
            for (byte x = 0; x < DungeonScreen.RenderDiameter; x++)
            {
                Point coord = screen.ChunkCoordinate + new Point(x - DungeonScreen.RenderRadius, y - DungeonScreen.RenderRadius);

                if (coord.X <= 0 || coord.Y <= 0 || coord.X >= screen.dungeon.data.GetLength(0) || coord.Y >= screen.dungeon.data.GetLength(1))
                {
                    continue;
                }

                screen.DungeonTilemaps[coord.X, coord.Y]?.Update(gameTime);
            }
        }
    }
}