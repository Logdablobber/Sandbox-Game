using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Sandbox_Game.Dungeon.Room;

namespace Sandbox_Game.Dungeon;

public class DungeonData
{
    public (byte, uint)[,] data; 
    public List<(Point, EnemySpawn)> enemySpawns;
}