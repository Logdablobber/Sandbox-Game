namespace Sandbox_Game.Dungeon;

public class DungeonData
{
    public (byte, uint)[,] data; 
}