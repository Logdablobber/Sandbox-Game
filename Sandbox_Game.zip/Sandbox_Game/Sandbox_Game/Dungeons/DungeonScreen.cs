using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autofac.Features.ResolveAnything;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended;
using MonoGame.Extended.Input;
using MonoGame.Extended.Screens;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.Tiled.Renderers;
using Sandbox_Game.Dungeon.Generator;
using Sandbox_Game.Dungeon.Rendering;
using Sandbox_Game.Dungeon.Room;
using Sandbox_Game.Entities.Player;
using Sandbox_Game.Entities.Projectiles;
using Sandbox_Game.LoadAssets;
using Sandbox_Game.MainScreen;
using Sandbox_Game.WorldGen;

namespace Sandbox_Game.Dungeon;

public class DungeonScreen : GameScreen
{
    private new Game1 Game => (Game1)base.Game;

    public const byte RenderRadius = 4;
    public const byte RenderDiameter = RenderRadius * 2 + 1;

    public bool DrawAllRooms = false;

    public byte DungeonWidth = 9;
    public byte DungeonHeight = 9;

    public Point ChunkCoordinate = new Point(0, 0);

    public PlayerController Player;

    public DungeonData dungeon;
    public TiledMapRenderer[,] DungeonTilemaps;

    private static FastRandom random = new FastRandom();

    public DungeonScreen(Game1 game) : base(game)
    {
        
    }

    public override void Initialize()
    {
        List<TiledMapTileset> tilesets = 
        [
            Game.Content.Load<TiledMapTileset>("Tiled/dungeon-floor-tileset"),
            Game.Content.Load<TiledMapTileset>("Tiled/dungeon-door-tileset"),
            Game.Content.Load<TiledMapTileset>("Tiled/dungeon-wall-tileset"),
        ];

        AssetLoader.LoadRooms(Game);

        dungeon = DungeonGenerator.Generate(DungeonWidth, DungeonHeight, 50, random.Next());
        DungeonTilemaps = DungeonGenerator.GenerateTilemap(dungeon, tilesets);

        var unmoveable_area = DungeonGenerator.GetUnMovableArea(dungeon);

        Player = new PlayerController(Game1.Animations["Player"], Vector2.Zero, Vector2.One, unmoveable_area);

        Player.Position = WorldGenerator.TileSize * new Vector2(DungeonGenerator.DungeonRoomWidth * DungeonWidth, DungeonGenerator.DungeonRoomHeight * DungeonHeight) * 0.5f;

        base.Initialize();
    }

    public override void Update(GameTime gameTime)
    {
        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        KeyboardStateExtended keystate = KeyboardExtended.GetState();

        Vector2 unrounded_chunk_coordinate = Game1.camera.Center / new Vector2(DungeonGenerator.DungeonRoomWidth * WorldGenerator.TileSize, DungeonGenerator.DungeonRoomHeight * WorldGenerator.TileSize);
        unrounded_chunk_coordinate.Floor();

        ChunkCoordinate = unrounded_chunk_coordinate.ToPoint();

        DungeonRenderer.Update(this, gameTime);

        ProjectileManager.Update(gameTime);

        Player.Update(gameTime);

        if (keystate.IsKeyDown(Keys.Z))
        {
            ViewFullMap();
        }
        else
        {
            Game1.camera.Position = Player.Position - (new Vector2(Game1.ReferenceWidth, Game1.ReferenceHeight) * 0.5f);
            Game1.camera.Zoom = 3f;
            DrawAllRooms = false;
        }
        
    }

    public override void Draw(GameTime gameTime)
    {
        var transformation_matrix = Game1.camera.GetViewMatrix();

        GraphicsDevice.Clear(Color.Black);

        Game1.Spritebatch.Begin(samplerState: SamplerState.PointClamp, transformMatrix:transformation_matrix);

        DungeonRenderer.Draw(this, transformation_matrix);

        ProjectileManager.Draw(gameTime);

        Player.Draw(gameTime);

        Game1.Spritebatch.End();
    }

    public void ViewFullMap()
    {
        Vector2 dungeon_size = WorldGenerator.TileSize * new Vector2(DungeonGenerator.DungeonRoomWidth * DungeonWidth, DungeonGenerator.DungeonRoomHeight * DungeonHeight);

        Game1.camera.LookAt(dungeon_size * 0.5f);

        Game1.camera.Zoom = Math.Min(Game1.ReferenceWidth / dungeon_size.X, Game1.ReferenceHeight / dungeon_size.Y);

        DrawAllRooms = true;
    }
}