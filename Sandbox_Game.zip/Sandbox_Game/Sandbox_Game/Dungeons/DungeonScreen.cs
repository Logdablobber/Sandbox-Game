using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autofac.Features.ResolveAnything;
using EpPathFinding.cs;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended;
using MonoGame.Extended.Graphics;
using MonoGame.Extended.Input;
using MonoGame.Extended.Screens;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.Tiled.Renderers;
using Sandbox_Game.Dungeon.EnemySpawning;
using Sandbox_Game.Dungeon.Generator;
using Sandbox_Game.Dungeon.Rendering;
using Sandbox_Game.Dungeon.Room;
using Sandbox_Game.Entities;
using Sandbox_Game.Entities.Enemies;
using Sandbox_Game.Entities.MovableArea;
using Sandbox_Game.Entities.Pathfinding;
using Sandbox_Game.Entities.Player;
using Sandbox_Game.Entities.Player.Spells;
using Sandbox_Game.UI;
using Sandbox_Game.WorldGen;

namespace Sandbox_Game.Dungeon;

public class DungeonScreen : GameScreen
{
    private new Game1 Game => (Game1)base.Game;

    public const byte RenderRadius = 4;
    public const byte RenderDiameter = RenderRadius * 2 + 1;

    public bool DrawAllRooms = false;

    public byte DungeonWidth = 9;
    public byte DungeonHeight = 9;

    public Point ChunkCoordinate = new Point(0, 0);

    public static PlayerController Player;
    public Vector2 PlayerSpellIconLocation => Game1.camera.Center + new Vector2(170, 50);

    public DungeonData dungeon;
    public TiledMapRenderer[,] DungeonTilemaps;

    private static FastRandom random = new FastRandom();

    AreaCollider unmoveable_area;

    StaticGrid pathfinding_area;

    public DungeonScreen(Game1 game) : base(game)
    {
        List<TiledMapTileset> tilesets = 
        [
            Game.Content.Load<TiledMapTileset>("Tiled/dungeon-floor-tileset"),
            Game.Content.Load<TiledMapTileset>("Tiled/dungeon-door-tileset"),
            Game.Content.Load<TiledMapTileset>("Tiled/dungeon-wall-tileset"),
        ];

        dungeon = DungeonGenerator.Generate(DungeonWidth, DungeonHeight, 50, 102);
        DungeonTilemaps = DungeonGenerator.GenerateTilemap(dungeon, tilesets);

        unmoveable_area = DungeonGenerator.GetUnMovableArea(dungeon);

        var spawn_position = WorldGenerator.TileSize * new Vector2(DungeonGenerator.DungeonRoomWidth * DungeonWidth, DungeonGenerator.DungeonRoomHeight * DungeonHeight) * 0.5f;

        var player_stats = new Stats
        {
            MaxHP = 100,
            Strength = 10,
            Speed = 100,
            AttackSpeed = 10,
            MaxMana = 100,
            DecimalManaRegenPerSecond = 0.1f,
        };

        Player = new PlayerController(new AnimatedSprite(Game1.Animations["Player"].Item1, Game1.Animations["Player"].Item2), spawn_position, Vector2.One, true, player_stats, unmoveable_area);

        var spell_background = new UIElement(new AnimatedSprite(Game1.Animations["Spell Background"].Item1, Game1.Animations["Spell Background"].Item2), new Vector2(226, 106), new Vector2(7f), 0);

        pathfinding_area = DungeonGenerator.GetPathfindingArea(dungeon);

        PathfindingManager.Initialize(pathfinding_area);

        EnemySpawner.SpawnEnemies(dungeon.enemySpawns, unmoveable_area);
    }

    public override void Initialize()
    {
        EntityManager.Initialize(unmoveable_area);

        base.Initialize();
    }

    public override void Update(GameTime gameTime)
    {
        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        KeyboardStateExtended keystate = KeyboardExtended.GetState();
        MouseStateExtended mousestate = MouseExtended.GetState();

        Vector2 unrounded_chunk_coordinate = Game1.camera.Center / new Vector2((DungeonGenerator.DungeonRoomWidth - 1) * WorldGenerator.TileSize, (DungeonGenerator.DungeonRoomHeight - 1) * WorldGenerator.TileSize);
        unrounded_chunk_coordinate.Floor();

        ChunkCoordinate = unrounded_chunk_coordinate.ToPoint();

        DungeonRenderer.Update(this, gameTime);

        EntityManager.UpdateAll(gameTime, true);

        UIManager.Update(gameTime);

        if (keystate.IsKeyDown(Keys.Z))
        {
            ViewFullMap();
        }
        else
        {
            Game1.camera.LookAt(Player.Position);
            Game1.camera.Zoom = 3f;
            DrawAllRooms = false;
        }
    }

    public override void Draw(GameTime gameTime)
    {
        var transformation_matrix = Game1.camera.GetViewMatrix();

        GraphicsDevice.Clear(Color.Black);

        Game1.Spritebatch.Begin(samplerState: SamplerState.PointClamp, transformMatrix:transformation_matrix);

        DungeonRenderer.Draw(this, transformation_matrix);

        EntityManager.DrawAll(gameTime, true);

        UIManager.Draw(gameTime, DrawAllRooms);

        Game1.Spritebatch.Draw(SpellLib.Spells[Player.SelectedSpell].Icon, PlayerSpellIconLocation, null, Color.White, 0, Vector2.Zero, 7f, SpriteEffects.None, 0f);

        Game1.Spritebatch.End();
    }

    public void ViewFullMap()
    {
        Vector2 dungeon_size = WorldGenerator.TileSize * new Vector2(DungeonGenerator.DungeonRoomWidth * DungeonWidth, DungeonGenerator.DungeonRoomHeight * DungeonHeight);

        Game1.camera.LookAt(dungeon_size * 0.5f);

        Game1.camera.Zoom = Math.Min(Game1.ReferenceWidth / dungeon_size.X, Game1.ReferenceHeight / dungeon_size.Y);

        DrawAllRooms = true;
    }
}