using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Sandbox_Game.Enums;

namespace Sandbox_Game.Dungeon.Room.Reader;

public static class RoomReader
{
    private const uint DoorColor = 0xFF_00_00_FF; // Red (255, 0, 0) A = 255
    private const uint WallColor = 0xFF_FF_00_00; // Blue (0, 0, 255) A = 255
    private const uint FloorColor = 0xFF_00_FF_00; // Green (0, 255, 0) A = 255
    private const uint BlankColor = 0x00_00_00_00; // Transparent (0, 0, 0) A = 0
    private static readonly uint[] EnemySpawnColors = // Later Indexs are higher leveled enemies
    [
        0xFF_00_FF_FF, // Yellow (255, 255, 0) A = 255
        0xFF_FF_00_FF, // Pink (255, 0, 255) A = 255
        0xFF_FF_FF_00, // Cyan (0, 255, 255) A = 255
    ];

    public const byte BlankIndex = 0;
    public const byte FloorIndex = 1;
    public const byte DoorIndex = 2;
    public const byte WallIndex = 3;

    private static readonly uint[] OrderedColors = [FloorColor, WallColor, DoorColor];

    public static DungeonRoom GenerateRoomFromImage(Game game, string path)
    {  
        DungeonRoom new_room = new()
        {
            Name = new FileInfo(path).Name
        };
        
        Texture2D texture = game.Content.Load<Texture2D>(path);

        GenerateRoomData(texture, out new_room.data, out new_room.layers, out new_room.xSize, out new_room.ySize, out new_room.enemySpawns);

        new_room.Doors = GetDoors(new_room.data);

        return new_room;
    }

    private static void GenerateRoomData(Texture2D texture, out byte[,] room_data, out byte[,,] layer_data, out byte xSize, out byte ySize, out List<EnemySpawn> enemy_spawns)
    {
        xSize = (byte)texture.Width;
        ySize = (byte)texture.Height;

        room_data = GenerateRoom(texture, out enemy_spawns);
        layer_data = ConnectRoomTiles(room_data);
    }

    private static byte[,] GenerateRoom(Texture2D texture, out List<EnemySpawn> enemySpawns)
    {
        enemySpawns = [];

        byte[,] room_data = new byte[texture.Width, texture.Height]; 

        uint[] texture_data = new uint[texture.Width * texture.Height];

        texture.GetData(texture_data);

        for (byte y = 0; y < texture.Height; y++)
        {
            for (byte x = 0; x < texture.Width; x++)
            {
                int index = y * texture.Width + x;

                switch (texture_data[index])
                {
                    case BlankColor:
                        room_data[x, y] = BlankIndex;
                        break;

                    case FloorColor:
                        room_data[x, y] = FloorIndex;
                        break;

                    case DoorColor:
                        room_data[x, y] = DoorIndex;
                        break;
                    
                    case WallColor:
                        room_data[x, y] = WallIndex;
                        break;

                    default:
                        if (EnemySpawnColors.Contains(texture_data[index]))
                        {
                            room_data[x, y] = FloorIndex;

                            byte CR = (byte)Array.IndexOf(EnemySpawnColors, texture_data[index]);

                            enemySpawns.Add(new EnemySpawn(x, y, CR));
                            break;
                        }
                        room_data[x, y] = 4;
                        break;
                }
            }
        }

        return room_data;
    }

    private static List<(byte, byte, Direction)> GetDoors(byte[,] room_data)
    {
        const byte surrounding_tiles_for_center = 2;

        byte width = (byte)room_data.GetLength(0);
        byte height = (byte)room_data.GetLength(1);

        List<(byte, byte, Direction)> doors = [];

        for (byte x = 0; x < width; x++)
        {
            for (byte y = 0; y < height; y++)
            {
                if (room_data[x, y] != 2)
                {
                    continue;
                }

                byte surrounding_door_tiles = 0b0000_0000;

                if (x != 0)
                {
                    if (room_data[x - 1, y] == 2)
                    {
                        surrounding_door_tiles += 0b1000_0001;
                    }
                }

                if (x != width - 1)
                {
                    if (room_data[x + 1, y] == 2)
                    {
                        surrounding_door_tiles += 0b0010_0001;
                    }
                }

                if (y != 0)
                {
                    if (room_data[x, y - 1] == 2)
                    {
                        surrounding_door_tiles += 0b0001_0001;
                    }
                }

                if (y != height - 1)
                {
                    if (room_data[x, y + 1] == 2)
                    {
                        surrounding_door_tiles += 0b0100_0001;
                    }
                }

                if ((surrounding_door_tiles & 0b0000_1111) < surrounding_tiles_for_center)
                {
                    continue;
                }

                Direction door_direction = Direction.None;

                switch (surrounding_door_tiles >> 4)
                {
                    case 0b0000_0101:
                        if (x > ((width - 1) / 2))
                        {
                            door_direction = Direction.Right;
                        }
                        else
                        {
                            door_direction = Direction.Left;
                        }
                        break;

                    case 0b0000_1010:
                        if (y > ((height - 1) / 2))
                        {
                            door_direction = Direction.Down;
                        }
                        else
                        {
                            door_direction = Direction.Up;
                        }
                        break;

                    default:
                        break;
                }

                doors.Add((x, y, door_direction));
            }
        }

        return doors;
    }

    private static byte[,,] ConnectRoomTiles(byte[,] room_data)
    {
        byte width = (byte)room_data.GetLength(0);
        byte height = (byte)room_data.GetLength(1);

        byte[,,] connected_tiles = new byte[OrderedColors.Length, width, height];

        // generate connected tilemap using offset method

        for (byte i = 1; i < OrderedColors.Length + 1; i++)
        {
            for (byte y = 0; y < height; y++)
            {
                for (byte x = 0; x < width; x++)
                {
                    byte tile_index = 0b0000;

                    if (x != 0 && y != 0)
                    {
                        if (room_data[x - 1, y - 1] == i)
                        {
                            tile_index |= 0b0001;
                        }
                    }
                    
                    if (y != 0)
                    {
                        if (room_data[x, y - 1] == i)
                        {
                            tile_index |= 0b0010;
                        }
                    }

                    if (room_data[x, y] == i)
                    {
                        tile_index |= 0b0100;
                    }

                    if (x != 0)
                    {
                        if (room_data[x - 1, y] == i)
                        {
                            tile_index |= 0b1000;
                        }
                    }

                    connected_tiles[i - 1, x, y] = tile_index;
                }
            }
        }

        return connected_tiles;
        
    }

}