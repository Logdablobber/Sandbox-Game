using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using MonoGame.Extended;
using Sandbox_Game.Dungeon.Generator;
using Sandbox_Game.Dungeon.Room;
using Sandbox_Game.Entities.Enemies;
using Sandbox_Game.Entities.MovableArea;
using Sandbox_Game.WorldGen;

namespace Sandbox_Game.Dungeon.EnemySpawning;

public static class EnemySpawner
{

	private static Random random = new Random();

	public static List<Enemy> SpawnEnemies(List<(Point, EnemySpawn)> enemy_spawns, AreaCollider movable_area) // Pairs of Chunk Coords to Enemy Spawn Locations
	{
		List<Enemy> enemies = [];

		foreach (var spawn in enemy_spawns)
		{
			int CR_level_modifier = 0;

			// if an enemy of that CR doesn't exist, spawn the nearest one of a level below that
			while (!EnemyLib.Enemies.ContainsKey((byte)(spawn.Item2.CRLevel + CR_level_modifier)) && spawn.Item2.CRLevel + CR_level_modifier >= 0)
			{
				CR_level_modifier -= 1;
			}

			if (spawn.Item2.CRLevel + CR_level_modifier < 0)
			{
				continue;
			}

			int index = random.Next(0, EnemyLib.Enemies[(byte)(spawn.Item2.CRLevel + CR_level_modifier)].Count - 1);

			EnemyData enemy = EnemyLib.Enemies[(byte)(spawn.Item2.CRLevel + CR_level_modifier)][index].Item2;

			Vector2 position = ((spawn.Item1.ToVector2() * new Vector2(DungeonGenerator.DungeonRoomWidth - 1, DungeonGenerator.DungeonRoomHeight - 1)) + new Vector2(spawn.Item2.x, spawn.Item2.y)) * WorldGenerator.TileSize;

			enemies.Add(new Enemy(enemy, position, Vector2.One, movable_area));
		}

		return enemies;
	}
}