using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Design;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Tiled;
using Sandbox_Game.Dungeon.Room.Reader;
using Sandbox_Game.Enums;
using Sandbox_Game.MainScreen;
using Sandbox_Game.WorldGen;

namespace Sandbox_Game.Dungeon.Room;

public class DungeonRoom
{ 
    public string Name;

    public byte[,] data;
    public byte[,,] layers;

    public byte xSize;
    public byte ySize;

    public List<(byte, byte, Direction)> Doors = [];

    public List<EnemySpawn> enemySpawns = [];

    public TiledMap GetTilemap(List<TiledMapTileset> tilesets)
    {
        var tilemap = new TiledMap(Name, "", xSize, ySize, WorldGenerator.TileSize, WorldGenerator.TileSize, TiledMapTileDrawOrder.LeftDown, TiledMapOrientation.Orthogonal);

        int first_gid = 0;
        foreach (var tileset in tilesets)
        {
            tilemap.AddTileset(tileset, first_gid);

            first_gid += tileset.TileCount;
        }

        for (int i = 0; i < layers.GetLength(0); i++)
        {
            var new_layer = new TiledMapTileLayer($"{i}", "", xSize, ySize, WorldGenerator.TileSize, WorldGenerator.TileSize, new Vector2(-0.5f));

            for (int x = 0; x < xSize; x++)
            {
                for (int y = 0; y < ySize; y++)
                {
                    new_layer.SetTile((ushort)x, (ushort)y, (uint)(layers[i, x, y] + (i * 16)));
                }
            }

            tilemap.AddLayer(new_layer);
        }

        return tilemap;
    }    
}

public struct EnemySpawn
{
    private byte _position;

    public byte x
    {
        readonly get
        {
            return (byte)(_position >> 4);
        }
        set 
        {
            _position &= 0b00001111;
            _position |= (byte)(value << 4);
        }
    }

    public byte y
    {
        readonly get
        {
            return (byte)(_position & 0b00001111);
        }
        set
        {
            _position &= 0b11110000;
            _position |= (byte)(value & 0b00001111);
        }
    }

    public byte CRLevel;

    public EnemySpawn(byte x, byte y, byte CRLevel)
    {
        this.x = x;
        this.y = y;
        this.CRLevel = CRLevel;
    }
}