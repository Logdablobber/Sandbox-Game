using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Design;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Tiled;
using Sandbox_Game.Dungeon.Room.Reader;
using Sandbox_Game.Enums;
using Sandbox_Game.MainScreen;
using Sandbox_Game.WorldGen;

namespace Sandbox_Game.Dungeon.Room;

public class DungeonRoom
{ 
    public string Name;

    public byte[,] data;
    public byte[,,] layers;

    public byte xSize;
    public byte ySize;

    public List<(byte, byte, Direction)> Doors = [];

    public TiledMap GetTilemap(List<TiledMapTileset> tilesets)
    {
        var tilemap = new TiledMap(Name, "", xSize, ySize, WorldGenerator.TileSize, WorldGenerator.TileSize, TiledMapTileDrawOrder.LeftDown, TiledMapOrientation.Orthogonal);

        int first_gid = 0;
        foreach (var tileset in tilesets)
        {
            tilemap.AddTileset(tileset, first_gid);

            first_gid += tileset.TileCount;
        }

        for (int i = 0; i < layers.GetLength(0); i++)
        {
            var new_layer = new TiledMapTileLayer($"{i}", "", xSize, ySize, WorldGenerator.TileSize, WorldGenerator.TileSize, new Vector2(-0.5f));

            for (int x = 0; x < xSize; x++)
            {
                for (int y = 0; y < ySize; y++)
                {
                    new_layer.SetTile((ushort)x, (ushort)y, (uint)(layers[i, x, y] + (i * 16)));
                }
            }

            tilemap.AddLayer(new_layer);
        }

        return tilemap;
    }

    
    
}