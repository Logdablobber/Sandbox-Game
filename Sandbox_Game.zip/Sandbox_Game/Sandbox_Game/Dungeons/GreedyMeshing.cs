using System.Collections;
using System.Collections.Generic;
using MonoGame.Extended.ECS;
using Microsoft.Xna.Framework;

namespace Sandbox_Game.Dungeon.GreedyMeshing;

public static class GreedyMesher
{
    public static List<Rectangle> Mesh(BitArray[] tiles, Vector2 scale)
    {
        List<(Point, Point)> boxes = [];

        //gready mesh the tiles
        //Note: I had to shallow clone the BitArrays every time I wanted to use them
        // this is because it is modified in place whenever you use a bitwise operation

        for (int y = 0; y < tiles.Length; y++)
        {
            var array_shifted_left = ((BitArray)tiles[y].Clone()).LeftShift(1).Not();
            var left_walls = (BitArray)tiles[y].Clone();
            left_walls.And(array_shifted_left);

            var array_shifted_right = ((BitArray)tiles[y].Clone()).RightShift(1).Not();
            var right_walls = (BitArray)tiles[y].Clone();
            right_walls.And(array_shifted_right);

            List<(int, int)> blocks = new List<(int,int)>();

            for (int x = 0; x < tiles[0].Count; x++)
            {
                if (!left_walls[x])
                {
                    continue;
                }

                (int, int) block = (x, -1);

                for (int x2 = x; x2 < tiles[0].Count; x2++)
                {
                    if (!right_walls[x2])
                    {
                        continue;
                    }

                    block.Item2 = x2 - x + 1;
                    x = x2;
                    break;
                }

                if (block.Item2 == -1)
                {
                    block.Item2 = tiles[0].Count - x;
                } 
                blocks.Add(block);
            }  

            foreach (var block in blocks)
            {
                BitArray block_bits = new BitArray(tiles[0].Count);

                for (int x = block.Item1; x < block.Item2 + block.Item1; x++)
                {
                    block_bits[x] = true;
                }

                int block_height = 1;

                for (int y2 = y+1; y2 < tiles.Length; y2++)
                {
                    // Checks if the current block is on the next row as well 
                    // Below is equivelant to maptiles[y2].And(block_bits) != block_bits
                    // I couldn't figure out why it wouldn't work normally :(
                    if (!((BitArray)tiles[y2].Clone()).And(block_bits).ContainsAll(block_bits))
                    {
                        break;
                    }
                    tiles[y2].And(((BitArray)block_bits.Clone()).Not());
                    
                    block_height += 1;
                }
                boxes.Add((new Point(block.Item1, y), new Point(block.Item2, block_height)));
            }
        }

        List<Rectangle> rectangles = [];

        foreach (var box in boxes)
        {
            rectangles.Add(new Rectangle((box.Item1.ToVector2() * scale).ToPoint(), (box.Item2.ToVector2() * scale).ToPoint()));
        }

        return rectangles;

    }
}