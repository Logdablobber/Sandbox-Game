using System.Collections;
using System.Collections.Generic;

namespace Sandbox_Game.Dungeon.Room;

public static class RoomLibrary
{
    public static Dictionary<byte, List<DungeonRoom>> Rooms = [];
}