using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Microsoft.Xna.Framework;
using MonoGame.Extended;
using MonoGame.Extended.ECS;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.Tiled.Renderers;
using Sandbox_Game.Dungeon.GreedyMeshing;
using Sandbox_Game.Dungeon.Room;
using Sandbox_Game.Dungeon.Room.Reader;
using Sandbox_Game.Entities.MovableArea;
using Sandbox_Game.Enums;
using Sandbox_Game.MainScreen;
using Sandbox_Game.WorldGen;

namespace Sandbox_Game.Dungeon.Generator;

public static class DungeonGenerator
{
    public const byte DungeonRoomWidth = 17;
    public const byte DungeonRoomHeight = 17;

    public static DungeonData Generate(byte width, byte height, uint iterations, int seed)
    {
        FastRandom random = new FastRandom(seed);

        byte[,] dungeon = new byte[width, height];

        for (byte x = 0; x < width; x++)
        {
            for (byte y = 0; y < height; y++)
            {
                dungeon[x, y] = 0; // one bit to represent each wall
            }
        }

        (byte, byte) current_point = ((byte)(width / 2), (byte)(height / 2));

        Direction previous_direction = Direction.None;

        for (uint i = 0; i < iterations; i++)
        {
            List<Direction> possible_directions = [];

            if (current_point.Item1 != 0)
            {
                possible_directions.Add(Direction.Left);
            }
            if (current_point.Item1 != width - 1)
            {
                possible_directions.Add(Direction.Right);
            }
            if (current_point.Item2 != 0)
            {
                possible_directions.Add(Direction.Up);
            }
            if (current_point.Item2 != height - 1)
            {
                possible_directions.Add(Direction.Down);
            }

            if (previous_direction != Direction.None)
            {
                possible_directions.Add(OpposingDirections.Get(previous_direction));
            }

            var next_direction = possible_directions[random.Next(0, possible_directions.Count - 1)];

            switch (next_direction) // move current point and break down walls inbetween
            {
                case Direction.Left: 
                    dungeon[current_point.Item1, current_point.Item2] |= 0b1000;
                    current_point = ((byte)(current_point.Item1 - 1), current_point.Item2);
                    dungeon[current_point.Item1, current_point.Item2] |= 0b0010;
                    break;

                case Direction.Right:
                    dungeon[current_point.Item1, current_point.Item2] |= 0b0010;
                    current_point = ((byte)(current_point.Item1 + 1), current_point.Item2);
                    dungeon[current_point.Item1, current_point.Item2] |= 0b1000;
                    break;

                case Direction.Up:
                    dungeon[current_point.Item1, current_point.Item2] |= 0b0001;
                    current_point = (current_point.Item1, (byte)(current_point.Item2 - 1));
                    dungeon[current_point.Item1, current_point.Item2] |= 0b0100;
                    break;
                    
                case Direction.Down:
                    dungeon[current_point.Item1, current_point.Item2] |= 0b0100;
                    current_point = (current_point.Item1, (byte)(current_point.Item2 + 1));
                    dungeon[current_point.Item1, current_point.Item2] |= 0b0001;
                    break;

                default:
                    break;
            }

            previous_direction = next_direction;
        }

        (byte, uint)[,] dungeon_data = new (byte, uint)[width, height];

        for (byte x = 0; x < width; x++)
        {
            for (byte y = 0; y < height; y++)
            {
                byte current_room = dungeon[x, y];

                if (current_room == 0)
                {
                    dungeon_data[x, y] = (0, 0);
                    continue;
                }

                uint room_index = (uint)random.Next(0, RoomLibrary.Rooms[current_room].Count - 1);

                dungeon_data[x, y] = (current_room, room_index);
            }
        }

        DungeonData new_dungeon = new DungeonData();

        new_dungeon.data = dungeon_data;

        return new_dungeon;
    }

    public static TiledMapRenderer[,] GenerateTilemap(DungeonData dungeon, List<TiledMapTileset> tilesets)
    {
        byte width = (byte)dungeon.data.GetLength(0);
        byte height = (byte)dungeon.data.GetLength(1);

        TiledMapRenderer[,] tilemaps = new TiledMapRenderer[width, height];

        for (byte x = 0; x < width; x++)
        {
            for (byte y = 0; y < height; y++)
            {
                byte room_door_index = dungeon.data[x, y].Item1;

                if (room_door_index == 0)
                {
                    continue;
                }

                uint room_index = dungeon.data[x, y].Item2;

                TiledMap room = RoomLibrary.Rooms[room_door_index][(int)room_index].GetTilemap(tilesets);

                Vector2 offset = new(x * WorldGenerator.TileSize * (DungeonRoomWidth - 1) - (0.5f * WorldGenerator.TileSize), y * WorldGenerator.TileSize * (DungeonRoomHeight - 1) - (0.5f * WorldGenerator.TileSize));

                foreach (var layer in room.Layers)
                {
                    layer.Offset = offset;
                }

                tilemaps[x, y] = new TiledMapRenderer(Game1.Graphics.GraphicsDevice, room);
            }
        }

        return tilemaps;
    }

    public static AreaCollider GetUnMovableArea(DungeonData dungeon)
    {
        byte width = (byte)dungeon.data.GetLength(0);
        byte height = (byte)dungeon.data.GetLength(1);

        BitArray[] moveable_area = new BitArray[height * (DungeonRoomHeight - 1)];

        for (int i = 0; i < width * (DungeonRoomWidth - 1); i++)
        {
            moveable_area[i] = new BitArray(width * (DungeonRoomWidth - 1));
        }

        for (byte x = 0; x < width; x++)
        {
            for (byte y = 0; y < height; y++)
            {
                for (byte x1 = 0; x1 < (DungeonRoomWidth - 1); x1++)
                {
                    var room_index = dungeon.data[x, y];
                    var room = RoomLibrary.Rooms[room_index.Item1][(int)room_index.Item2];

                    for (byte y1 = 0; y1 < (DungeonRoomHeight - 1); y1++)
                    {
                        Point coords = new Point((x * (DungeonRoomWidth - 1)) + x1, (y * (DungeonRoomHeight - 1)) + y1);

                        byte tile = room.data[x1, y1];

                        moveable_area[coords.Y][coords.X] = tile == 0 || tile == 3;
                    }
                }
            }
        }

        List<Rectangle> rectangles = GreedyMesher.Mesh(moveable_area, new Vector2(WorldGenerator.TileSize));

        AreaCollider area = new();

        foreach (var rect in rectangles)
        {
            var bounding_box = new BoundingBox(new Vector3(rect.Location.ToVector2(), 0), new Vector3(rect.Right, rect.Bottom, 0));

            area.AddCollider(bounding_box);
        }

        return area;
    }
}