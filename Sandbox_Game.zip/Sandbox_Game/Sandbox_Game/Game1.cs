﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended;
using MonoGame.Extended.ECS;
using MonoGame.Extended.Graphics;
using MonoGame.Extended.Input;
using MonoGame.Extended.Input.InputListeners;
using MonoGame.Extended.Screens;
using MonoGame.Extended.Screens.Transitions;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.ViewportAdapters;
using Sandbox_Game.Dungeon;
using Sandbox_Game.LoadAssets;
using Sandbox_Game.MainScreen;

namespace Sandbox_Game;

public class Game1 : Game
{
    public static Dictionary<string, AnimatedSprite> Animations = new();

    public static GraphicsDeviceManager Graphics;
    public static SpriteBatch Spritebatch;

    private readonly ScreenManager _screenManager;

    public static OrthographicCamera camera;
    public const int ReferenceWidth = 1920, ReferenceHeight = 1080;

    WorldScreen worldScreen;
    DungeonScreen dungeonScreen;

    public Game1()
    {
        Graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        _screenManager = new ScreenManager();
        Window.AllowUserResizing = true;
        Components.Add(_screenManager);
    }

    private void LoadWorldScreen()
    {
        _screenManager.LoadScreen(worldScreen, new FadeTransition(Graphics.GraphicsDevice, Color.Black));
    }

    private void LoadDungeonScreen()
    {
        _screenManager.LoadScreen(dungeonScreen, new FadeTransition(Graphics.GraphicsDevice, Color.Black));
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        AssetLoader.LoadAssets(this);

        worldScreen = new WorldScreen(this);

        dungeonScreen = new DungeonScreen(this);

        var viewport_adapter = new BoxingViewportAdapter(Window, GraphicsDevice, ReferenceWidth, ReferenceHeight);
        camera = new OrthographicCamera(viewport_adapter);
        camera.Zoom = 3f;

        LoadWorldScreen();

        base.Initialize();
    }

    protected override void LoadContent()
    {
        Spritebatch = new SpriteBatch(GraphicsDevice);

        // TODO: use this.Content to load your game content here
    }

    protected override void Update(GameTime gameTime)
    {
        KeyboardExtended.Update();
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        // TODO: Add your update logic here
        KeyboardStateExtended keystate = KeyboardExtended.GetState();

        if (keystate.WasKeyReleased(Keys.Q))
        {
            LoadWorldScreen();
        }
        if (keystate.WasKeyReleased(Keys.E))
        {
            LoadDungeonScreen();
        }


        base.Update(gameTime);
    }
}
