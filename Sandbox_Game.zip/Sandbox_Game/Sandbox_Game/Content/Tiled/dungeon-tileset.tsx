<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="dungeon-tileset" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="../dungeon.png" width="16" height="16"/>
 <tile id="0">
  <properties>
   <property name="blank-property" type="bool" value="false"/>
  </properties>
 </tile>
</tileset>
