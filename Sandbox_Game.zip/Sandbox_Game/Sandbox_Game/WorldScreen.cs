using MonoGame.Extended;
using Microsoft.Xna.Framework;
using MonoGame.Extended.Screens;
using Sandbox_Game;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.Tiled.Renderers;
using Sandbox_Game.LoadAssets;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Input;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using Sandbox_Game.WorldGen;
using WorldGen.Layers;
using Sandbox_Game.Entities.Player;
using MonoGame.Extended.Graphics;
using Sandbox_Game.Entities;

namespace Sandbox_Game.MainScreen;

class WorldScreen : GameScreen
{
    private new Game1 Game => (Game1)base.Game;

    public const byte RenderRadius = 4;
    public const byte RenderDiameter = RenderRadius * 2 + 1;
    public static Dictionary<Point, TiledMapRenderer> tileMapRenderers;

    public Point ChunkCoordinate = new Point(0, 0);

    public static Dictionary<Point, TiledMap> tilemaps = new();
    public static Dictionary<Point, Chunk> chunks = new();

    public static int seed;

    public PlayerController Player;

    private static FastRandom random = new FastRandom();

    public WorldScreen(Game1 game) : base(game)
    {
        tileMapRenderers = new Dictionary<Point, TiledMapRenderer>();

        
        uint tileset_gid = 0;
        for (int i = 0; i < WorldLayers.Layers.Length; i++)
        {
            var layer = WorldLayers.Layers[i];
            layer.FirstGID = tileset_gid;
            layer.tileset = Game.Content.Load<TiledMapTileset>($"Tiled/{layer.TilesetFileName}");
            tileset_gid += (uint)layer.tileset.Tiles.Count;
            WorldLayers.Layers[i] = layer;
        }

        WorldLayers.DungeonTileset = Game.Content.Load<TiledMapTileset>("Tiled/dungeon-tileset");
        WorldLayers.DungeonTilesetGID = tileset_gid;

        seed = random.Next();

        WorldGenerator.Initialize(seed);

        TilemapRenderingManager.UpdateRenderers(new GameTime(), ChunkCoordinate);

        Player = new PlayerController(new AnimatedSprite(Game1.Animations["Player"].Item1, Game1.Animations["Player"].Item2), Vector2.Zero, Vector2.One, false);
    }

    public override void Initialize()
    {
        base.Initialize();
    }

    public override void Update(GameTime gameTime)
    {
        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        Vector2 unrounded_chunk_coordinate = Game1.camera.Center / (WorldGenerator.ChunkSize * WorldGenerator.TileSize);
        unrounded_chunk_coordinate.Floor();

        ChunkCoordinate = unrounded_chunk_coordinate.ToPoint();

        TilemapRenderingManager.Update(gameTime, ChunkCoordinate);

        KeyboardStateExtended keystate = KeyboardExtended.GetState();

        EntityManager.UpdateAll(gameTime, false);

        Game1.camera.Position = Player.Position - (new Vector2(Game1.ReferenceWidth, Game1.ReferenceHeight) * 0.5f);
    }

    public override void Draw(GameTime gameTime)
    {
        var transformation_matrix = Game1.camera.GetViewMatrix();

        GraphicsDevice.Clear(Color.CornflowerBlue);

        Game1.Spritebatch.Begin(samplerState: SamplerState.PointClamp, transformMatrix:transformation_matrix);

        TilemapRenderingManager.DrawRenderers(transformation_matrix);

        EntityManager.DrawAll(gameTime, false);

        Game1.Spritebatch.End();
    }
}