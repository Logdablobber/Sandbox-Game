using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Graphics;
using MonoGame.Extended.Tiled;
using Sandbox_Game.Animations;
using Sandbox_Game.Dungeon.Room;
using Sandbox_Game.Dungeon.Room.Reader;
using Sandbox_Game.Entities.Enemies;
using Sandbox_Game.Entities.Enemies.Reader;
using Sandbox_Game.Entities.Player.Spells;
using Sandbox_Game.Entities.Projectiles;
using Sandbox_Game.Entities.Projectiles.Reader;
using Sandbox_Game.Enums;

namespace Sandbox_Game.LoadAssets;

public static class AssetLoader
{
    public static void LoadAssets(Game game)
    {
        LoadAnimations(game);
        LoadRooms(game);
        LoadEnemies();
        LoadProjectiles();
        LoadSpells(game);
    }

    private static void LoadAnimations(Game game)
    {
        DirectoryInfo room_dir = new DirectoryInfo(@"Content\Animations");

        FileInfo[] files = room_dir.GetFiles("*.json");

        foreach (var file in files)
        {
            SpriteSheet new_animation = AnimationReader.ReadAnimationJSON(game, file.FullName, out string first_animation);

            string name = new_animation.Name.Split('/')[new_animation.Name.Split('/').Length - 1];

            Game1.Animations.Add(name, (new_animation, first_animation));
        }
    }

    private static void LoadRooms(Game game)
    {
        DirectoryInfo room_dir = new DirectoryInfo(@"Content\Rooms");

        FileInfo[] files = room_dir.GetFiles("*.xnb");

        foreach (var file in files)
        {
            DungeonRoom room = RoomReader.GenerateRoomFromImage(game, $"Rooms/{file.Name.Remove(file.Name.Length - 4)}");

            byte door_index = 0;

            foreach (var door in room.Doors)
            {
                switch (door.Item3)
                {
                    case Direction.Up:
                        door_index |= 0b0001;
                        break;

                    case Direction.Right:
                        door_index |= 0b0010;
                        break;

                    case Direction.Down:
                        door_index |= 0b0100;
                        break;

                    case Direction.Left:
                        door_index |= 0b1000;
                        break;

                    default:
                        break;
                }
            }

            if (!RoomLibrary.Rooms.ContainsKey(door_index))
            {
                RoomLibrary.Rooms.Add(door_index, [room]);
            }
            else
            {
                RoomLibrary.Rooms[door_index].Add(room);
            }
        }
    }

    private static void LoadEnemies()
    {
        DirectoryInfo room_dir = new DirectoryInfo(@"Content\Enemies");

        FileInfo[] files = room_dir.GetFiles("*.json");

        foreach (var file in files)
        {
            EnemyData data = EnemyReader.ReadEnemyJson(file.FullName);

            data.spriteSheet = Game1.Animations[data.AnimationName].Item1;
            data.first_animation = Game1.Animations[data.AnimationName].Item2;

            EnemyLib.Enemies.TryAdd(data.CR, []);
            EnemyLib.Enemies[data.CR].Add((data.Name, data));
        }
    }

    private static void LoadProjectiles()
    {
        DirectoryInfo room_dir = new DirectoryInfo(@"Content\Projectiles");

        FileInfo[] files = room_dir.GetFiles("*.json");

        foreach (var file in files)
        {
            ProjectileData data = ProjectileReader.ReadProjectileJson(file.FullName);

            data.spriteSheet = Game1.Animations[data.AnimationName].Item1;
            data.first_animation = Game1.Animations[data.AnimationName].Item2;

            ProjectileLib.Projectiles.Add(data.Name, data);
        }
    }

    private static void LoadSpells(Game game)
    {
        DirectoryInfo room_dir = new DirectoryInfo(@"Content\Spells");

        FileInfo[] files = room_dir.GetFiles("*.json");

        foreach (var file in files)
        {
            SpellData data = SpellReader.ReadSpellFromJson(file.FullName);

            data.Icon = game.Content.Load<Texture2D>(data.IconPath);

            SpellLib.Spells.Add(data.Name, data);
        }
    }
}