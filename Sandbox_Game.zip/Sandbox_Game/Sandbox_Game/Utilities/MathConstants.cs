namespace Sandbox_Game.Utilities.Constants;

public static class Consts
{
    public const float Root2 = 1.41421356237f;
    public const float Root2Over2 = Root2 / 2;
}
