namespace Sandbox_Game.Utilities.Constants;

public static class Consts
{
    public const float Root2Over2 = 0.70710678118f;
}
