using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq.Expressions;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.BitmapFonts;

namespace Sandbox_Game.Utilities.Debugging;

public static class DebugHelper
{
    public static bool Debugging;

    public static List<(string, object)> DebugData = [];
    public static List<(string, Func<object>)> DebugLambdas = [];

    const float DebugLineSpacing = 10f;

    public static void Draw()
    {
        if (Debugging)
        {
            for (int i = 0; i < DebugData.Count; i++)
            {
                var item = DebugData[i];

                string text = item.Item1 + item.Item2.ToString();

                Game1.Spritebatch.DrawString(Game1.DebugFont, text, new Vector2(10, DebugLineSpacing * i), Color.Black, 0, Vector2.One, 5f, SpriteEffects.None, 0);
            }

            for (int i = 0; i < DebugLambdas.Count; i++)
            {
                var item = DebugLambdas[i];

                string text = item.Item1 + item.Item2().ToString();

                Game1.Spritebatch.DrawString(Game1.DebugFont, text, new Vector2(10, DebugLineSpacing * (i + DebugData.Count)), Color.Black, 0, Vector2.One, 5f, SpriteEffects.None, 0);
            }  
        }
    }

    public static void TrackVariable(string label, object variable)
    {
        DebugData.Add((label, variable));
    }

    public static void TrackLambda(string label, Func<object> lambda)
    {
        DebugLambdas.Add((label, lambda));
    }

}