using System;
using System.Threading;

namespace Sandbox_Game.Utilities.Threads;

public static class ThreadManager
{
    public static void AddToQueue(Action action)
    {
        ThreadPool.QueueUserWorkItem((state) => {
            action();
        });
    }
}