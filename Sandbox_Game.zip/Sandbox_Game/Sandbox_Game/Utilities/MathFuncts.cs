using Microsoft.Xna.Framework;

namespace Sandbox_Game.Utilities.Functions;

public static class Functs
{
	public static float InverseLerp(float min, float max, float value)
	{
		if (value <= min)
		{
			return 0;
		}
		else if (value >= max)
		{
			return 1;
		}

		return (value - min) / (max - min);
	}
}